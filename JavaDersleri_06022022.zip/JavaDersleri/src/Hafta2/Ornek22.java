package Hafta2;

public class Ornek22 {
    public static void main(String[] args) {


        String metin = "Merhaba Dünya Dünya !";
        System.out.println("Metin: "+metin);
        System.out.println("Karakter uzunluğu: "+metin.length()); //15
        System.out.println("İlk karakteri: "+metin.charAt(0)); //M
        System.out.println("Metni küçük harfe dönüştürür: "+metin.toLowerCase());
        System.out.println("Metni büyük harfe dönüştürür: "+metin.toUpperCase());

        //Metin içerisinde aranan kelimenin/harfin ilk bulunduğu indisi döner
        //bulamazsa -1 döner.

        int metinIndexOf = metin.indexOf('a');
        System.out.println(metinIndexOf);
        if(metinIndexOf==-1){
            System.out.println("Metin içerisinde ay kelimesi bulunamadı !");
        }else{
            System.out.println("Metin içerisinde ay kelimesinin ilk bulunduğu index:"+metinIndexOf);
        }


        int metinLastIndexOf = metin.lastIndexOf("Dünya");
        System.out.println(metinLastIndexOf);


        //

        if("Merhaba Dünya Dünya !".equals(metin)){
            System.out.println("Metin değeri şerif değerine eşittir.");
        }else{
            System.out.println("Metin değeri şerif değerine eşit değildir.");
        }

        if(metin.contains("aba")){
            System.out.println("Metin içerisinde aba kelimesi bulunuyor");
        }else{
            System.out.println("Metin içerisinde aba kelimesi bulunmuyor");
        }
        metin = metin.replace("Dünya","Ay");
        System.out.println(metin);

        //String içerisinde belirtilen karaktere göre parçalama işlemi yapar.
        String meyveler = "Elma,Armut,Kiraz";
        String[] dizi = meyveler.split(",");

        for (String a:dizi) {
            System.out.println(dizi[0]);
        }


        // belirtilen başlangıç ve bitiş indisleri aralığındaki değeri okuyabilmek
        //için kullanılır.
        String il = "yunanistanbulgaristan";
        System.out.println(il.substring(5,13));

        String html = "<html><head><title>Şerif GÜNGÖR BLOG</title></head><body>title</body></html>";

        String sonuc = html
                .substring(html.indexOf("<title>"),html.indexOf("</title>"))
                .replace("<title>","");

        System.out.println(sonuc);






    }
}
