package Hafta2;

import java.util.Scanner;

public class Ornek23 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Kullanıcı adı giriniz");
        String username = sc.next();
        System.out.println("Şifre giriniz");
        String pass = sc.next();

        if(username.isEmpty() && pass.isEmpty()){
            System.out.println("Kullanıcı adı ve şifre boş geçilemez !");
        }else{
            if(username.equals("admin") && pass.equals("admin123")){
                System.out.println("Giriş başarılı");
            }else{
                System.out.println("Hatalı giriş");
            }
        }

    }
}
