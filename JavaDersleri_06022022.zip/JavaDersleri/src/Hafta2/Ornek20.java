package Hafta2;

public class Ornek20 {

    public static void main(String[] args) {

        /*
        Foreach döngüsü dizi elemanlarını iterate etmek için kullanılır.
         */

        String[] meyveler = new String[5];
        meyveler[0] = "Elma";
        meyveler[1]="Erik";
        meyveler[2]="Kiraz";
        meyveler[3]="Vişne";
        meyveler[4]="Nar";

        for (String eleman:meyveler) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(eleman);
        }


    }

}
