package Hafta3;

public class Ornek30 {


    // Şerif Güngör -> ŞeRiF GüNgÖr



    public static String buyukluKucukluYazdir(String metin){
        String gecici="";
        for (int i = 0; i < metin.length(); i++) {
            if(i%2==1){
                gecici +=  (""+metin.charAt(i)).toUpperCase();
            }else{
                gecici += (""+metin.charAt(i)).toLowerCase();
                //Character.toString(metin.charAt(i)).toLowerCase();
            }
        }
        return gecici;
    }

    public static void main(String[] args) {

        System.out.println(buyukluKucukluYazdir("arıbilgiandroid"));

    }




}
