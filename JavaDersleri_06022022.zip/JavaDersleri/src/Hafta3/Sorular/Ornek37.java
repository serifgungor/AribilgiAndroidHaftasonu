package Hafta3.Sorular;

import java.util.Scanner;

public class Ornek37 {
    public static int[] bireyler(){
        Scanner sc=new Scanner(System.in);
        System.out.print("Kaç kişilik bir ailesiniz?");
        int[] dizi = new int[sc.nextInt()];
        for (int i = 0; i < dizi.length ; i++) {
            System.out.println((i + 1)+ " kişinin yaşını giriniz=") ;
            dizi[i]= sc.nextInt();
        }
        return dizi;
    }
    public static double sonuc(int[] aile){
        double d = 0;
        for (int i = 0; i < aile.length ; i++) {
            d+= aile[i];
        }
        return d/ aile.length;

    }

    public static void main(String[] args) {
        double s= sonuc(bireyler());
        System.out.println("Ailenin yaş ortalaması" + s);

    }
}
