package Hafta3.Sorular;

import java.util.Scanner;

public class Ornek36 {
    public static Scanner sc;
    public static boolean sonuc(double vize, double f){
        return (vize*0.40)+(f*0.60)>=50 ?true : false;
    }

    public static void secim(){
        sc = new Scanner(System.in);
        System.out.print("Vize notunuzu giriniz:");
        double vize = sc.nextDouble();
        System.out.print("Final notunuzu giriniz:");
        double f = sc.nextDouble();
        if((vize>=0 && vize<=100)&&(f>=0 && f<=100)){
            if(sonuc(vize,f))
                System.out.println("Başarılı. \n Notunuz:"+((vize*0.40)+(f*0.60)));
            else
                System.out.println("Başarısız. \n Notunuz:"+((vize*0.40)+(f*0.60)));
        }else{
            System.out.println("Vize ve Final notları 0-100 aralığında olmalıdır.");
        }


    }
    public static void main(String[] args) {
        secim();
    }

}
