package Hafta3.Sorular;

import java.util.Scanner;

public class Ornek38 {
    public static double zam(double urunFiyati){
        return urunFiyati*1.25;
    }
    public static double indirim(double urunFiyati){
        return urunFiyati-(urunFiyati*0.25);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Ürün fiyatını giriniz:");
        double urunFiyati = sc.nextDouble();
        System.out.println("Ürünün zamlı fiyatı: "+zam(urunFiyati));
        System.out.print("Ürünün indirimli fiyatı: "+indirim(urunFiyati));
    }
}
