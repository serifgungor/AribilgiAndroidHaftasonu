package Hafta3;

public class Ornek32 {

    public double alan(double kisaKenar,double uzunKenar){
        return kisaKenar*uzunKenar;
    }
    public double cevre(double kisaKenar,double uzunKenar){
        return  (kisaKenar+uzunKenar)*2;
    }
    public static void main(String[] args) {
        Ornek32 o = new Ornek32();
        double uzunKenar = 20;
        double kisaKenar = 10;
        System.out.println("Dikdörtgenin alanı: "+o.alan(kisaKenar,uzunKenar));
        System.out.println("Dikdörtgenin çevresi: "+o.cevre(kisaKenar,uzunKenar));
    }
}
