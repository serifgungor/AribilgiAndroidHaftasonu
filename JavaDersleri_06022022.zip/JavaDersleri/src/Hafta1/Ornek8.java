package Hafta1;

import java.util.Scanner;

public class Ornek8 {
    public static void main(String[] args) {
        Scanner veriOku = new Scanner(System.in);

        System.out.println("1. sayıyı giriniz");
        float sayi1 = veriOku.nextFloat();
        System.out.println("2. sayıyı giriniz");
        float sayi2 = veriOku.nextFloat();

        float toplamaSonuc = sayi1+sayi2;
        float cikarmaSonuc = sayi1-sayi2;
        float carpmaSonuc = sayi1*sayi2;
        float bolmeSonuc = sayi1/sayi2;

        System.out.println("Toplama Sonucu:"+toplamaSonuc);
        System.out.println("Çıkarma Sonucu:"+cikarmaSonuc);
        System.out.println("Çarpma Sonucu:"+carpmaSonuc);
        System.out.println("Bölme Sonucu:"+bolmeSonuc);

    }
}
