package com.serifgungor.habergoruntuleyici;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    String url = "";

    public void butonaTikla(View view){

        switch (view.getId()){
            case R.id.ensonhaber:
                url = "https://www.ensonhaber.com/";
                break;
            case R.id.haber7:
                url = "https://www.haber7.com/";
                break;
            case R.id.haberlercom:
                url = "https://www.haberler.com/";
                break;
            case R.id.haberturk:
                url = "https://www.haberturk.com/";
                break;
            case R.id.hurriyet:
                url = "https://www.hurriyet.com.tr/";
                break;
            case R.id.milliyet:
                url = "https://www.milliyet.com.tr/";
                break;
        }
        Intent intent = new Intent(getApplicationContext(),WebViewActivity.class);
        intent.putExtra("site_adresi",url);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}