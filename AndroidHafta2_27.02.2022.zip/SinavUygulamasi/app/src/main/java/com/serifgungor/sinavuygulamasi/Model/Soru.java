package com.serifgungor.sinavuygulamasi.Model;

public class Soru {
    private int id;
    private String baslik;
    private String secenekA;
    private String secenekB;
    private String secenekC;
    private String secenekD;
    private char dogruYanitHarf;

    public Soru() {
    }

    public Soru(int id, String baslik, String secenekA, String secenekB, String secenekC, String secenekD, char dogruYanitHarf) {
        this.id = id;
        this.baslik = baslik;
        this.secenekA = secenekA;
        this.secenekB = secenekB;
        this.secenekC = secenekC;
        this.secenekD = secenekD;
        this.dogruYanitHarf = dogruYanitHarf;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getSecenekA() {
        return secenekA;
    }

    public void setSecenekA(String secenekA) {
        this.secenekA = secenekA;
    }

    public String getSecenekB() {
        return secenekB;
    }

    public void setSecenekB(String secenekB) {
        this.secenekB = secenekB;
    }

    public String getSecenekC() {
        return secenekC;
    }

    public void setSecenekC(String secenekC) {
        this.secenekC = secenekC;
    }

    public String getSecenekD() {
        return secenekD;
    }

    public void setSecenekD(String secenekD) {
        this.secenekD = secenekD;
    }

    public char getDogruYanitHarf() {
        return dogruYanitHarf;
    }

    public void setDogruYanitHarf(char dogruYanitHarf) {
        this.dogruYanitHarf = dogruYanitHarf;
    }
}
