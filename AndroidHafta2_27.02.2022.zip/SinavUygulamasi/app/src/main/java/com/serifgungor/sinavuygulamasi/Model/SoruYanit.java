package com.serifgungor.sinavuygulamasi.Model;

public class SoruYanit {
    private int soru_id;
    private char dogru_yanit_harf;
    private char kullanici_yanit_harf;

    public SoruYanit() {
    }

    public SoruYanit(int soru_id, char dogru_yanit_harf, char kullanici_yanit_harf) {
        this.soru_id = soru_id;
        this.dogru_yanit_harf = dogru_yanit_harf;
        this.kullanici_yanit_harf = kullanici_yanit_harf;
    }

    public int getSoru_id() {
        return soru_id;
    }

    public void setSoru_id(int soru_id) {
        this.soru_id = soru_id;
    }

    public char getDogru_yanit_harf() {
        return dogru_yanit_harf;
    }

    public void setDogru_yanit_harf(char dogru_yanit_harf) {
        this.dogru_yanit_harf = dogru_yanit_harf;
    }

    public char getKullanici_yanit_harf() {
        return kullanici_yanit_harf;
    }

    public void setKullanici_yanit_harf(char kullanici_yanit_harf) {
        this.kullanici_yanit_harf = kullanici_yanit_harf;
    }
}
