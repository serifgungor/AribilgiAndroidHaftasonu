package com.serifgungor.sinavuygulamasi.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.serifgungor.sinavuygulamasi.Model.Soru;
import com.serifgungor.sinavuygulamasi.Model.SoruYanit;
import com.serifgungor.sinavuygulamasi.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView tvSoruBaslik;
    Button btnIlerle;
    RadioGroup rg;
    RadioButton rbA, rbB, rbC, rbD;
    int index = 0;

    ArrayList<SoruYanit> soruYanitlari = new ArrayList<>();


    public ArrayList<Soru> sorulariGetir() {
        ArrayList<Soru> list = new ArrayList<>();
        list.add(new Soru(1, "Başlık 1", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'a'));
        list.add(new Soru(2, "Başlık 2", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'a'));
        list.add(new Soru(3, "Başlık 3", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'a'));
        list.add(new Soru(4, "Başlık 4", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'a'));
        list.add(new Soru(5, "Başlık 5", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'a'));
        list.add(new Soru(6, "Başlık 6", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'a'));
        list.add(new Soru(7, "Başlık 7", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'a'));
        list.add(new Soru(8, "Başlık 8", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'a'));
        list.add(new Soru(9, "Başlık 9", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'a'));
        list.add(new Soru(10, "Başlık 10", "Yanıt a", "Yanıt b", "Yanıt c", "Yanıt d", 'd'));
        return list;
    }

    public void soruyuGetir(int soruId){
        rg.jumpDrawablesToCurrentState();
        rg.clearCheck();
        Soru s = sorulariGetir().get(soruId);
        tvSoruBaslik.setText(s.getBaslik());
        rbA.setText(s.getSecenekA());
        rbB.setText(s.getSecenekB());
        rbC.setText(s.getSecenekC());
        rbD.setText(s.getSecenekD());

        //Son soru gösteriliyorsa
        if(soruId==(sorulariGetir().size()-1)){
            btnIlerle.setText("Bitir");
        }
    }

    public void init(){
        rg = findViewById(R.id.rg);
        btnIlerle = findViewById(R.id.btnIlerle);
        tvSoruBaslik = findViewById(R.id.tvSoruBaslik);
        rbA = findViewById(R.id.rbA);
        rbB = findViewById(R.id.rbB);
        rbC = findViewById(R.id.rbC);
        rbD = findViewById(R.id.rbD);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        soruyuGetir(index);
        btnIlerle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(index==sorulariGetir().size()-1){
                    Toast.makeText(MainActivity.this, "Sınav Bitti", Toast.LENGTH_SHORT).show();
                }else{
                    char kullaniciYanit = ' ';
                    if(rbA.isChecked()){
                        kullaniciYanit = 'a';
                    }else if(rbB.isChecked()){
                        kullaniciYanit = 'b';
                    }else if(rbC.isChecked()){
                        kullaniciYanit = 'c';
                    }else if(rbD.isChecked()){
                        kullaniciYanit = 'd';
                    }
                    soruYanitlari.add(new SoruYanit(
                            sorulariGetir().get(index).getId(),
                            sorulariGetir().get(index).getDogruYanitHarf(),
                            kullaniciYanit
                    ));
                    index++;
                    soruyuGetir(index);
                }
            }
        });
    }


}