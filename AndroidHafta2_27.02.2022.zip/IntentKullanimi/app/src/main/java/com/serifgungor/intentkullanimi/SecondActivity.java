package com.serifgungor.intentkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        tv = findViewById(R.id.tvSayi2);
        String ad = getIntent().getStringExtra("ad");
        String soyad = getIntent().getStringExtra("soyad");
        tv.setText(ad + " "+soyad);


    }
}