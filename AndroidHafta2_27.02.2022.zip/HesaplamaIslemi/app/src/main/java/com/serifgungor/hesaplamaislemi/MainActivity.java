package com.serifgungor.hesaplamaislemi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, bC, bCarpim, bEsittir, bToplama, bCikartma, bBolme;
    TextView giris;
    EditText number1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b0 = findViewById(R.id.b0);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);
        bC = findViewById(R.id.bC);
        bCarpim = findViewById(R.id.bCarpim);
        bEsittir = findViewById(R.id.bEsittir);
        bToplama = findViewById(R.id.bToplama);
        bCikartma = findViewById(R.id.bCikartma);
        bBolme = findViewById(R.id.bBolme);
        giris = findViewById(R.id.giris);
        ArrayList<String> islemler = new ArrayList<>();
        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b0 = "" + 0;
                giris.setText("" + giris.getText() + b0);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b1 = "" + 1;
                giris.setText("" + giris.getText() + b1);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b2 = "" + 2;
                giris.setText("" + giris.getText() + b2);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b3 = "" + 3;
                giris.setText("" + giris.getText() + b3);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b4 = "" + 4;
                giris.setText("" + giris.getText() + b4);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b5 = "" + 5;
                giris.setText("" + giris.getText() + b5);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b6 = "" + 6;
                giris.setText("" + giris.getText() + b6);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b7 = "" + 7;
                giris.setText("" + giris.getText() + b7);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b8 = "" + 8;
                giris.setText("" + giris.getText() + b8);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String b9 = "" + 9;
                giris.setText("" + giris.getText() + b9);
                Log.d("bb", "onClick: " + islemler);
            }
        });
        bToplama.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                islemler.add(giris.getText().toString());
                islemler.add("+");
                giris.setText("");
                Log.d("bb", "onClick: " + islemler);
            }
        });
        bCikartma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                islemler.add(giris.getText().toString());
                islemler.add("-");
                giris.setText("");
                Log.d("bb", "onClick: " + islemler);
            }
        });
        bCarpim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                islemler.add(giris.getText().toString());
                islemler.add("*");
                giris.setText("");
                Log.d("bb", "onClick: " + islemler);
            }
        });
        bBolme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                islemler.add(giris.getText().toString());
                islemler.add("/");
                giris.setText("");
                Log.d("bb", "onClick: " + islemler);
            }
        });
        bEsittir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                islemler.add(giris.getText().toString());
                Log.d("bb", "onClick: " + islemler);
                for (int i = 0; i < islemler.size(); i++) {
                    if (i % 2 == 1) {
                        if (islemler.get(i).equalsIgnoreCase("/")) {
                            double sayi1 = 0, sayi2 = 0, isonuc = 0;
                            String son = "", son2 = "";
                            sayi1 = Double.parseDouble(islemler.get(islemler.indexOf("/") - 1));
                            sayi2 = Double.parseDouble(islemler.get(islemler.indexOf("/") + 1));
                            isonuc = sayi1 / sayi2;
                            int b = (int) isonuc;
                            son = Integer.toString(b);
                            islemler.remove((islemler.indexOf("/") - 1));
                            islemler.remove((islemler.indexOf("/") + 1));
                            islemler.set(islemler.indexOf("/"), son);
                        }
                    }
                }
                Log.d("bb", "onClick: " + islemler);
                giris.setText(islemler.get(0));
            }
        });
        bC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                islemler.clear();
                giris.setText("");
                Log.d("bb", "onClick: " + islemler);
            }
        });


    }
}