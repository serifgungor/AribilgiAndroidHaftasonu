package com.myapplication.Model;

public class Ogrenci {
    public int id;
    public String ogrenciAdi;
    public String ogrenciSoyadi;
    public String ogrenciTelNo;

    public Ogrenci() {
    }

    public Ogrenci(int id, String ogrenciAdi, String ogrenciSoyadi, String ogrenciTelNo) {
        this.id = id;
        this.ogrenciAdi = ogrenciAdi;
        this.ogrenciSoyadi = ogrenciSoyadi;
        this.ogrenciTelNo = ogrenciTelNo;
    }

    @Override
    public String toString() {
        return id +" " + ogrenciAdi +" "+ ogrenciSoyadi +" "+ ogrenciTelNo;
    }
}
