package com.myapplication.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.myapplication.Model.Ogrenci;
import com.myapplication.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseReference myRef;
    ArrayList<Ogrenci> ogrenciler = new ArrayList<>();
    ListView listView;
    ArrayAdapter<Ogrenci> arrayAdapter;

    public void init() {
        listView = findViewById(R.id.listView);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("Öğrenci Listele");

        init();
        myRef = FirebaseDatabase.getInstance().getReference().child("ogrenciler");
       /*
       myRef.push().setValue(new Ogrenci(1,"Kadir","GÜNGÖR","02120001122"));
       myRef.push().setValue(new Ogrenci(2,"Yılmaz","Tüzen","02120001133"));
       */
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ogrenciler.clear();
                for (DataSnapshot sn : snapshot.getChildren()) {
                    Ogrenci ogrenci = sn.getValue(Ogrenci.class);
                    ogrenciler.add(ogrenci);
                    Log.d("öğrenci", ogrenci.ogrenciAdi + " " + ogrenci.ogrenciSoyadi);
                }
                arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,ogrenciler);
                listView.setAdapter(arrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.id_add){
            startActivity(new Intent(getApplicationContext(),OgrenciEkleActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }
}