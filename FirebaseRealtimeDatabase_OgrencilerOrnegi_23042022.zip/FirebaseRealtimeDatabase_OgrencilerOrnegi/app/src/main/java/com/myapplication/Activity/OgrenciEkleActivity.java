package com.myapplication.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.myapplication.Model.Ogrenci;
import com.myapplication.R;

public class OgrenciEkleActivity extends AppCompatActivity {
    DatabaseReference myRef;
    EditText etId,etAd,etSoyad,etTelefon;
    Button btnOgrenciEkle;

    public void init(){
        myRef = FirebaseDatabase.getInstance().getReference().child("ogrenciler");

        this.setTitle("Öğrenci Ekle");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        etId = findViewById(R.id.etId);
        etAd = findViewById(R.id.etAd);
        etSoyad = findViewById(R.id.etSoyad);
        etTelefon = findViewById(R.id.etTelefon);
        btnOgrenciEkle = findViewById(R.id.btnOgrenciEkle);
        btnOgrenciEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myRef.push().setValue(
                        new Ogrenci(
                                Integer.valueOf(etId.getText().toString()),
                                etAd.getText().toString(),
                                etSoyad.getText().toString(),
                                etTelefon.getText().toString()
                 ));
                finish();
            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ogrenci_ekle);

        init();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}