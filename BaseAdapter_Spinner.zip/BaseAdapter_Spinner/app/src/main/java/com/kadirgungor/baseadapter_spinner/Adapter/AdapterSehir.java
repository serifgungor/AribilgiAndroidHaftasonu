package com.kadirgungor.baseadapter_spinner.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.kadirgungor.baseadapter_spinner.Model.Sehir;
import com.kadirgungor.baseadapter_spinner.R;

import java.util.ArrayList;

public class AdapterSehir extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private Context context;
    private ArrayList<Sehir> sehirler;

    public AdapterSehir() {
    }

    public AdapterSehir(Context context, ArrayList<Sehir> sehirler) {
        this.layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.context = context;
        this.sehirler = sehirler;
    }

    @Override
    public int getCount() {
        return sehirler.size();
    }

    @Override
    public Sehir getItem(int i) {
        return sehirler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
       View v = layoutInflater.inflate(R.layout.sehir_row,null);

        ImageView iv = v.findViewById(R.id.bayrak);
        TextView sehir = v.findViewById(R.id.sehir);

        iv.setImageResource(sehirler.get(i).getUlkeBayrak());
        sehir.setText(sehirler.get(i).getSehirAdi());

       return v;
    }
}
