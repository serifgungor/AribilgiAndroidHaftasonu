package com.kadirgungor.baseadapter_spinner.Model;

public class Sehir {
    private String sehirAdi;
    private int ulkeBayrak;

    public Sehir() {
    }

    public Sehir(String sehirAdi, int ulkeBayrak) {
        this.sehirAdi = sehirAdi;
        this.ulkeBayrak = ulkeBayrak;
    }

    public String getSehirAdi() {
        return sehirAdi;
    }

    public void setSehirAdi(String sehirAdi) {
        this.sehirAdi = sehirAdi;
    }

    public int getUlkeBayrak() {
        return ulkeBayrak;
    }

    public void setUlkeBayrak(int ulkeBayrak) {
        this.ulkeBayrak = ulkeBayrak;
    }
}
