package com.kadirgungor.baseadapter_spinner.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Spinner;

import com.kadirgungor.baseadapter_spinner.Adapter.AdapterSehir;
import com.kadirgungor.baseadapter_spinner.Model.Sehir;
import com.kadirgungor.baseadapter_spinner.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Spinner spinner;
    ArrayList<Sehir> sehirler = new ArrayList<>();
    AdapterSehir adapterSehir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spinner);

        sehirler.add(new Sehir("İstanbul",R.drawable.tr));
        sehirler.add(new Sehir("Ankara",R.drawable.tr));
        sehirler.add(new Sehir("İzmir",R.drawable.tr));
        sehirler.add(new Sehir("Bursa",R.drawable.tr));
        sehirler.add(new Sehir("Edirne",R.drawable.tr));
        sehirler.add(new Sehir("Bakü",R.drawable.az));
        sehirler.add(new Sehir("Liman",R.drawable.az));
        sehirler.add(new Sehir("Oğuz",R.drawable.az));
        sehirler.add(new Sehir("Lefkoşa",R.drawable.kktc));
        sehirler.add(new Sehir("Gazimağusa",R.drawable.kktc));
        sehirler.add(new Sehir("Girne",R.drawable.kktc));

        adapterSehir = new AdapterSehir(getApplicationContext(),sehirler);
        spinner.setAdapter(adapterSehir);
    }
}