package com.sos_oyunu.android.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.nex3z.flowlayout.FlowLayout;
import com.sos_oyunu.android.Model.Oda;
import com.sos_oyunu.android.R;

public class OyunActivity extends AppCompatActivity implements View.OnClickListener {

    FlowLayout flowLayout;
    Oda oda;
    DatabaseReference myRef;
    TextView tvOyuncularinAdlari,tvOyuncuSira;
    String kurucu,ikinciOyuncu;

    public void bosKutulariUret(){
        for (int i = 1; i <=9 ; i++) {
            final ImageView iv = new ImageView(getApplicationContext());
            iv.setImageResource(R.drawable.bos);
            iv.setOnClickListener(this::onClick);
            iv.setTag("bos,kutu"+i);
            iv.setId(100+i);
            flowLayout.addView(iv);
        }
    }

    public void init(){
        oda = (Oda)getIntent().getSerializableExtra("oda");
        flowLayout = findViewById(R.id.flowLayout);
        flowLayout.setMaxRows(3);
        myRef = FirebaseDatabase.getInstance().getReference().child("odalar/"+oda.odaId);
        tvOyuncularinAdlari = findViewById(R.id.tvOyuncularinAdlari);
        tvOyuncuSira = findViewById(R.id.tvOyuncuSira);
        tvOyuncularinAdlari.setText(oda.oyuncu1 + "\nVS\n" + oda.oyuncu2);
        tvOyuncuSira.setText("ŞUAN\n"+oda.islem_kisi+".OYUNCU");

        kurucu = oda.oyuncu1;
        ikinciOyuncu = getIntent().getStringExtra("oyuncu2");
        if(ikinciOyuncu!=null){
            //odaya ben katıldıysam
            oda.islem_kisi = 1;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyun);
        this.getSupportActionBar().hide(); //toolbarı gizledik

        init();
        bosKutulariUret();
        kutularinIceriginiGetir();

        Log.d("yanit",oda.toString());

        if(!"null".equals(oda.oyuncu2)){
            myRef.child("oyuncu2").setValue(oda.oyuncu2);
        }

        ikinciOyuncuOyundami();
        herseyiGuncelle();
    }

    public void herseyiGuncelle(){
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                for (DataSnapshot sn : snapshot.getChildren()) {
                    Log.d("yanit",sn.toString());
                    if("oyuncu2".equals(sn.getKey())){
                        oda.oyuncu2 = (String) sn.getValue();
                    }
                    if("oyuncu1".equals(sn.getKey())){
                        oda.oyuncu1 = (String) sn.getValue();
                    }
                }



                tvOyuncularinAdlari.setText(oda.oyuncu1 + "\nVS\n" + oda.oyuncu2);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void ikinciOyuncuOyundami(){
        myRef.child("oyuncu2").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(!"null".equals(snapshot.getValue())){
                    //Oyun başladı
                    tvOyuncuSira.setText("ŞUAN\n"+oda.islem_kisi+".OYUNCU");
                }else{
                    tvOyuncuSira.setText("2. oyuncu\nbekleniyor.");
                    //Oyuncu bekleniyor.
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void kutularinIceriginiGetir(){
        myRef.child("aksiyon").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot sn : snapshot.getChildren()) {
                    Log.d("deneme",sn.toString());
                    String kutuDegeri = (String) sn.getValue();
                    int kutuId = 100+Integer.parseInt((String)sn.getKey().replace("kutu",""));

                    ImageView iv = findViewById(kutuId);
                    if("S".equals(kutuDegeri)){
                        iv.setImageResource(R.drawable.s);
                    }else if("O".equals(kutuDegeri)){
                        iv.setImageResource(R.drawable.o);
                    }else{
                        iv.setImageResource(R.drawable.bos);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public void onClick(View view) {
        ImageView iv = (ImageView)view;
        if(iv.getTag().toString().startsWith("bos")){
            if(oda.islem_kisi==1){ //1.oyuncu işlem yapar
                iv.setImageResource(R.drawable.s);
                String[] splitted = iv.getTag().toString().split(",");
                myRef.child("aksiyon").child(splitted[1]).setValue("O");
                myRef.child("islem_kisi").setValue("2");
                oda.islem_kisi = 2;
            }else if(oda.islem_kisi==2){ //2.oyuncu işlem yapar
                iv.setImageResource(R.drawable.s);
                String[] splitted = iv.getTag().toString().split(",");
                myRef.child("aksiyon").child(splitted[1]).setValue("S");
                myRef.child("islem_kisi").setValue("1");
                oda.islem_kisi = 1;
            }
            //Toast.makeText(getApplicationContext(), "tıklandı", Toast.LENGTH_SHORT).show();
        }
    }
}