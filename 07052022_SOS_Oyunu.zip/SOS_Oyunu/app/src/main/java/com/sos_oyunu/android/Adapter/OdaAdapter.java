package com.sos_oyunu.android.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.sos_oyunu.android.Model.Oda;
import com.sos_oyunu.android.R;

import java.util.ArrayList;

public class OdaAdapter extends BaseAdapter {
    private ArrayList<Oda> odalar;
    private Context context;
    private LayoutInflater layoutInflater;

    public OdaAdapter() {
    }

    public OdaAdapter(ArrayList<Oda> odalar, Context context) {
        this.odalar = odalar;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return odalar.size();
    }

    @Override
    public Oda getItem(int i) {
        return odalar.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = layoutInflater.inflate(R.layout.vs_row,null);
        TextView tvOyuncu1 = v.findViewById(R.id.tvOyuncu1);
        TextView tvOyuncu2 = v.findViewById(R.id.tvOyuncu2);
        TextView tvOdaId = v.findViewById(R.id.tvOdaId);
        LinearLayout LinearLayoutRow = v.findViewById(R.id.LinearLayoutRow);

        tvOyuncu1.setText(""+odalar.get(i).oyuncu1);
        if("null".equals(odalar.get(i).oyuncu2)){
            tvOyuncu2.setText("?");
            LinearLayoutRow.setBackgroundColor(Color.parseColor("#664CAF50"));
        }else{
            tvOyuncu2.setText(""+odalar.get(i).oyuncu2);
            LinearLayoutRow.setBackgroundColor(Color.parseColor("#66E91E63"));
        }
        tvOdaId.setText(odalar.get(i).odaId+". oda");

        return v;
    }
}
