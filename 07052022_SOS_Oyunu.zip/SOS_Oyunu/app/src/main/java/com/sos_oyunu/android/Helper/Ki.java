package com.sos_oyunu.android.Helper;

public class Ki {

    public int[] k1 = new int[]{1,2,3};
    public int[] k2 = new int[]{4,5,6};
    public int[] k3 = new int[]{7,8,9};
    public int[] k4 = new int[]{3,6,9};
    public int[] k5 = new int[]{2,5,8};
    public int[] k6 = new int[]{1,4,7};
    public int[] k7 = new int[]{3,5,7};

}
