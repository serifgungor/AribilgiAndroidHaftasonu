package com.sos_oyunu.android.Model;

import java.io.Serializable;
import java.util.ArrayList;

public class Oda implements Serializable {
    public int odaId;
    public int islem_kisi;
    public ArrayList<String> aksiyon;
    public String oyuncu1;
    public String oyuncu2;

    public Oda() {
    }

    public Oda(int odaId, int islem_kisi, ArrayList<String> aksiyon, String oyuncu1, String oyuncu2) {
        this.odaId = odaId;
        this.islem_kisi = islem_kisi;
        this.aksiyon = aksiyon;
        this.oyuncu1 = oyuncu1;
        this.oyuncu2 = oyuncu2;
    }

    @Override
    public String toString() {
        return "Oda{" +
                "odaId=" + odaId +
                ", islem_kisi=" + islem_kisi +
                ", aksiyon=" + aksiyon +
                ", oyuncu1='" + oyuncu1 + '\'' +
                ", oyuncu2='" + oyuncu2 + '\'' +
                '}';
    }
}
