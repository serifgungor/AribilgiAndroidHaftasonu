<?php

require_once("class.coreDatabase.php");
//require_once("class.coreDatabaseSqlite.php");
//Created by Şerif GÜNGÖR, 22.04.2015 23:17

//Database settings
$db_charset = "utf8";
$db_driver = "mysql";
$db_driver_port = "3306";
$db_sqlite_file="test.db";
/*Old file name ise config.php*/

$coreDatabase = new Db($db_host,$db_name,$db_user,$db_pass,$db_charset);
//$coreDatabaseSqlite = new DbSqlite();

/*
//PHP DATA OJBECTS (PDO) CLASS  (for using the OOP in PHP)
//Written by Şerif GÜNGÖR - www.serifgungor.com
//Last update: 08.10.2014
// !!!!!!!!! Critical note if you connect database with query code you write table or database name to lower case !
*/
//header('Content-Type: text/html; charset=utf-8'); // header for fix to character problems in select query results 

//SELECT YOUR DRIVER FOR CONNECT THE DATABASE
static $critical_functions = 0; //0 or 1

//SUPPORTED FUNCTIONS
// How to using ? - closeDB();

/* Need authorization for use this functions */
// How to using ? - deleteDatabase("asa");
// How to using ? - deleteTable("sa");
// How to using ? - renameTable("serif","sa");
// How to using ? - deleteAllResults("USERS");
// How to using ? - dumpDatabase("outputfilename",".sql");
// ok How to using - copyTable("myTable","myNewTable",1); // 1 copy with table row datas

/* GET, SET, DELETE, UPDATE, COUNT (INSERT, SELECT, COUNT, UPDATE AND DELETE FUNCTIONS) */
// How to using ? - getOptionalValues(/*TABLE*/"users",/*COLUMNS*/"user_id,name,surname,user_email",/*WHERE*/"reg_ok=1",/*ORDER BY*/"user_id",/*ASC DESC*/"DESC",/*LIMIT*/250,NULL);
// OK ÖNEMLİ How to using ? - setOptionalValues("sa","int1,int2,int3,string1","1,2,4,'sa'");
// ok How to using ? - deleteResultInQuery("USERS","age",20);
// ok How to using ? - updateResultInQuery("sa","gh","4444","5555"); // sa tablosundaki gh kolonunda 4444 gördüğünü 5555 yap
// ok How to using ? - selectCountInTable("USERS");
// ok How to using ? - print_r(flexyQuery("SELECT * FROM USERS WHERE `email_sent_ok`=2"));

/* SELECT/ADD/DELETE/CHANGE COLUMNS */
// ok How to using ? - selectAllColumn("USERS_OTHER_REGISTRATION_DETAILS",1);  //returns array
// ok How to using ? - addColumnThisTable("sa","S0S0","INT",5);
// ok How to using ? - deleteColumnThisTable("TABLE","column"); //tablodaki colon sayısı 1den fazla ise çalışır
// ok How to using ? - changeColumnThisTable("sa","asde","asdeme","VARCHAR","50"); //sa tablosundaki asde kolonundaki asdeme olarak ve tipini varchar 50 yap 
// ok How to using ? - print_r(showTables());
	
// ok How to using ? - selectCountInTable_OptionalValues("USERS","user_email = 'blabla and user_password = 'blabla'");	
	
//SELECTION DATABASE WITH ARRAY (SENT TO PDO)
$dbArray = (object) array(
	'dbhost' => ":host=".$db_host,
	'dbdriver' => $db_driver,
	'dbdriver_port' => ";port=".$db_driver_port,
	'dbname' => ";dbname=".$db_name,
	'dbcharset' => ";charset=".$db_charset,
	'dbuser' => $db_user,
	'dbpass' => $db_pass,
);

$lastInsertId = "";

switch($db_driver){
	case "mysql":
	//CONNECTION DATABASE WITH PDO
		try{
			$db = new PDO($dbArray->dbdriver.$dbArray->dbhost.$dbArray->dbdriver_port.$dbArray->dbname.$dbArray->dbcharset, $dbArray->dbuser, $dbArray->dbpass);
		}catch (PDOException $e) {
			//echo 'Connection failed: ' . $e->getMessage();
			echo "MySQLi Connection failed !";
		}
		break;
	case "sqlite":
	//CONNECTION DATABASE WITH PDO
		try{
			$db = new PDO("sqlite:".$db_sqlite_file);
		}catch (PDOException $e) {
			//echo 'Connection failed: ' . $e->getMessage();
			echo "SQLite Connection failed !";
		}
		break;
}


	
	/*
	$query = $db->query("select USERS.reg_lang hreflang, user_blogname from USERS_PERSONAL_BLOG, USERS WHERE blog_mode = 1 and USERS.user_id = USERS_PERSONAL_BLOG.user_id order by blog_id desc LIMIT 50000", PDO::FETCH_ASSOC);
	if ( $query->rowCount() ){
		 foreach( $query as $row ){
			  print $row['user_blogname']."<br />";
	
		 }
	}
	*/
	
//CLOSING DATABASE WITH FUNCTION
function closeDB(){
	global $db;
	$db = null;
	//$this->pdo = null;
}
// How to using ? - closeDB();

function deleteDatabase($DATABASE){
	global $db;
	global $critical_functions;
	if($critical_functions === 1){
		$res = $db->prepare("DROP DATABASE ".$DATABASE);
		$res->execute();
	}else{
		echo "Critical query disabled !";
	}
}
// How to using ? - deleteDatabase("asa");
	
function deleteTable($TABLE){
	global $db;
	global $critical_functions;
	if($critical_functions === 1){
		$res = $db->prepare("DROP TABLE ".$TABLE);
		$res->execute();
	}else{
		echo "Critical query disabled !";
	}
}
// How to using ? - deleteTable("sa");
	
function renameTable($CURRENT_TABLE_NAME,$NEW_TABLE_NAME){
	global $db;
	global $critical_functions;
	if($critical_functions === 1){
		$res = $db->prepare("RENAME TABLE ".$CURRENT_TABLE_NAME." TO ".$NEW_TABLE_NAME);
		$res->execute();
	}else{
		echo "Critical query disabled !";
	}
}
// How to using ? - renameTable("serif","sa");
	
function deleteAllResults($TABLE){
	global $db;
	global $critical_functions;
	if($critical_functions === 1){
		$delete = $db->exec("DELETE FROM ".$TABLE);
		print 'Total '.$delete.' result deleted!';
	}else{
		echo "Critical query disabled !";
	}
}
// How to using ? - deleteAllResults("users");
	
function selectAllColumn($TABLE,$SelectCount){ //returns array
	global $db;
	$res = $db->prepare("SELECT * FROM ".$TABLE." LIMIT ".$SelectCount);
	$res->execute();
	//fetch tek satır veri çeker, fetchAll tüm satırları çeker
	if($SelectCount <= 1){
		$result = $res->fetch(PDO::FETCH_ASSOC); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
	}else if($SelectCount > 1){
		$result = $res->fetchAll(PDO::FETCH_ASSOC); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
	}else{
		$result = $res->fetch(PDO::FETCH_ASSOC); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
	}
	return $result;
}
// How to using ? - print_r(selectAllColumn("users_other_registration_details",1));
		
function addColumnThisTable($TABLE,$NEW_COLUMN_NAME,$NEW_COLUMN_TYPE,$NEW_COLUMN_LENGTH){
	global $db;
	$res = $db->prepare("ALTER TABLE ".$TABLE." ADD ".$NEW_COLUMN_NAME." ".$NEW_COLUMN_TYPE."(".$NEW_COLUMN_LENGTH.") NOT NULL");
	$res->execute();
}
// How to using ? - addColumnThisTable("sa","S0S0","INT",5);
	
function deleteColumnThisTable($TABLE,$COLUMN_NAME){
	global $db;
	$res = $db->prepare("ALTER TABLE ".$TABLE." DROP ".$COLUMN_NAME);
	$res->execute();
}
// How to using ? - deleteColumnThisTable("table","column");
	
function changeColumnThisTable($TABLE,$COLUMN_NAME,$NEW_COLUMN_NAME,$NEW_COLUMN_TYPE,$NEW_COLUMN_LENGTH){
	global $db;
	$res = $db->prepare("ALTER TABLE ".$TABLE." CHANGE ".$COLUMN_NAME." ".$NEW_COLUMN_NAME." ".$NEW_COLUMN_TYPE."(".$NEW_COLUMN_LENGTH.") NOT NULL");
	$res->execute();
}
// How to using ? - changeColumnThisTable("sa","asde","asdeme","VARCHAR","50");
	
function getOptionalValues($TABLE, $columns, $WHERE, $ORDERBY_column, $ASC_or_DESC, $LIMIT, $TABLETYPE){
	global $db;
	$query = $db->query('SELECT '.$columns.' FROM '.$TABLE.' WHERE '.$WHERE.' ORDER BY '.$ORDERBY_column.' '.$ASC_or_DESC.' LIMIT '.$LIMIT);
	if($columns != "*"){
		/*foreach($query as $row){
			$sColumns = explode(",", $columns);
			for($i=0; $i < count($sColumns); $i++){
				echo $row[''.$sColumns[$i].'']." ";
			}
			echo "<br>";
		}
		*/
			$query->execute();
			//fetch tek satır veri çeker, fetchAll tüm satırları çeker
			if($LIMIT <= 1){
				$result = $query->fetch(PDO::FETCH_ASSOC); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
			}else if($LIMIT > 1){
				$result = $query->fetchAll(PDO::FETCH_ASSOC); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
			}else{
				$result = $query->fetch(PDO::FETCH_ASSOC); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
			}
			return $result;
	}else{
			echo "Oopps, with this function you can not see all the data. !";
	}
}
// How to using ? - getOptionalValues(/*TABLE*/"users",/*COLUMNS*/"user_id,name,surname,user_email",/*WHERE*/"reg_ok=1",/*ORDER BY*/"user_id",/*ASC DESC*/"DESC",/*LIMIT*/250,NULL);

function getOptionalValuesFlexyQuery($Query){
	global $db;
	$query = $db->query($Query, PDO::FETCH_ASSOC);
	$query->execute();
			//fetch tek satır veri çeker, fetchAll tüm satırları çeker
			if($LIMIT <= 1){
				$result = $query->fetch(PDO::FETCH_ASSOC); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
			}else if($LIMIT > 1){
				$result = $query->fetchAll(PDO::FETCH_ASSOC); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
			}else{
				$result = $query->fetch(PDO::FETCH_ASSOC); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
			}
	return $result;
}

function executeSql($str){
	global $db;
	$insert = $str;
	$stmt = $db->exec($insert);
}

function setOptionalValues($TABLE, $columns, $columns_value){
	global $db;
	try{
		$db->exec('INSERT INTO '.$TABLE.' ('.$columns.') VALUES ('.$columns_value.')');
		return "1";
	}catch (PDOException $e) {
		//echo 'Connection failed: ' . $e->getMessage();
		return "2";
		//echo "data inserting problem";
	}
}
// How to using ? - setOptionalValues("sa","int1,int2,int3,string1","1,2,4,'sa'");
	
function setOptionalValues_withLastId($TABLE, $columns, $columns_value){
	global $db;
	global $lastInsertId;
	try{
		$insert = $db->exec('INSERT INTO '.$TABLE.' ('.$columns.') VALUES ('.$columns_value.')');
		if($insert){
			$id = $db->lastInsertId();
		}else{
			$id = "-1";
		}
		$lastInsertId = $id;
		return $id;
	}catch (PDOException $e) {
		//echo 'Connection failed: ' . $e->getMessage();
		return "-1";
		//echo "data inserting problem";
	}
}

function getLastInsertId(){
	global $lastInsertId;
	return $lastInsertId;
	
}	
	
function deleteResultInQuery($TABLE,$COLUMN_IN_WHICH,$MATCHING){
	global $db;
	try{
		$db->exec('DELETE FROM '.$TABLE.' WHERE '.$COLUMN_IN_WHICH.' = '.$MATCHING);
		return 1;
	}catch (PDOException $e) {
		//echo 'Connection failed: ' . $e->getMessage();
		return 2;
	}
}
// How to using ? - deleteResultInQuery("USERS","age",20);
	
function updateResultInQuery($TABLE,$WHERE,$CURRENT_RESULT,$NEW_RESULT){
	global $db;
	$query = $db->prepare('UPDATE '.$TABLE.' SET '.$WHERE.' = :'.$NEW_RESULT.' WHERE '.$WHERE.' = :'.$CURRENT_RESULT);
	$update = $query->execute(array(
	':'.$NEW_RESULT.'' => $NEW_RESULT,
	':'.$CURRENT_RESULT.'' => $CURRENT_RESULT
	));
	if($update){
		//echo "ok";
	}
}
// How to using ? - updateResultInQuery("sa","gh","4444","5555"); //sa tablosunun gh sütununda 4444 gördüğünü 5555 yap

function updateResultRowInQuery($TABLE,$SETCOLOUMN,$SETVALUE,$WHERECOLOUMN,$WHEREVALUE){
	global $db;
	try{
		$sql = "UPDATE $TABLE SET $SETCOLOUMN='$SETVALUE' WHERE $WHERECOLOUMN=$WHEREVALUE";
		// Prepare statement
		$query = $db->prepare($sql);
		// execute the query
		$query->execute();
		return "1";
	}catch (PDOException $e) {
		return "2";
	}
}
//updateResultRowInQuery("__blog","blog_do_viewcount",$view_count+1,"id",$id);

function bindFields($fields){
    end($fields); $lastField = key($fields);
    $bindString = ' ';
    foreach($fields as $field => $data){ 
        $bindString .= $field . '=:' . $field; 
        $bindString .= ($field === $lastField ? ' ' : ',');
    }
    return $bindString;
}

function updateResultRowInQueryWithArray($TABLE,$SET,$WHERE){
	global $db;
	try{
		$sql = "UPDATE $TABLE SET $SET WHERE $WHERE";
		// Prepare statement
		$query = $db->prepare($sql);
		// execute the query
		$query->execute();
		return "1";
	}catch (PDOException $e) {
		//echo 'Connection failed: ' . $e->getMessage();
		return "2";
		//echo "data inserting problem";
	}
	
}


function showTableColumnTypes($tableName){
	global $db;
	$query = $db->prepare("DESCRIBE ".$tableName);
	$query->execute();
	$result = $query->fetchAll(PDO::FETCH_ASSOC);
	return $result;
}


function downloadDatabase(){
	global $db;
	global $db_name;
	$dt = fopen($db_name.'_'.date("d_m_Y__H_i_s").".sql", 'w');
	
$string = "-- Serif GUNGOR'S MySQL Dump
-- Version 1.0.0 -- http://www.serifgungor.com
-- Developed by Serif GUNGOR
--
-- SQL file Created Datetime: ".date("d.m.Y H:i:s")."
-- This file: ".$db_name.'_'.date("d_m_Y__H_i_s").".sql
-- Server version: ".$_SERVER["SERVER_SOFTWARE"]." 
-- PHP version: ".phpversion()."
--
-- Database: `".$db_name."`
-- Table Count: ".count(showTables())."
--
";
fwrite($dt, $string);
//$string = $string."\n\n";
//fwrite($dt, "\n\n");
for($i=0; $i<count(showTables()); $i++){
	//CREATE TABLE
	$tableName = showTables()[$i];
	//$string = $string.showCreateTable($tableName).";";
	//$string = $string."\n\n";
	
	//

	fwrite($dt, str_replace('CREATE TABLE ','CREATE TABLE IF NOT EXISTS ',showCreateTable($tableName)).";");
	//fwrite($dt, "\n\n");
	$val = selectInTable2("select * from ".$tableName);
	
	for($j = 0; $j<count($val); $j++){
		//$string = $string. "INSERT INTO ".$tableName." VALUES (";
		fwrite($dt, "INSERT INTO ".$tableName." VALUES (");
		for($k=0; $k<count($val[$j]); $k++){
			
			$data=strval($val[$j][$k]);
			//$string = $string. "'".htmlspecialchars(addslashes($data))."'";
			
			//fwrite($dt, "'".htmlspecialchars(addslashes($data))."'");
			

$type = showTableColumnTypes($tableName)[$k]['Type'];

if(substr($type, 2)=="int") {
	fwrite($dt, htmlspecialchars(addslashes($data)));
}else{
	fwrite($dt, "'".htmlspecialchars(addslashes($data))."'");
}
			
			if ($k<(count($val[$j])-1)){
				//$string = $string. ", ";
				fwrite($dt, ",");
			}
			
		}
		//$string = $string. ");";
		fwrite($dt, ");");
	}
	
	
}


fclose($dt);
//Ve işimiz bittiğinde fwrite() ile dosyayı kapatıyoruz.


return $string;


}


function showCreateTable($tableName){
	global $db;
	$query = $db->prepare("SHOW CREATE TABLE ".$tableName);
	$query->execute();
	$result = $query->fetch(PDO::FETCH_ASSOC);
	return $result['Create Table'];
}
// How to using - print_r(showCreateTable("__blog"));



/* 
//This is a critical function, please you don't change or you be careful !
*/
function flexyQuery_forLogin($FULL_QUERY,$Array){
	global $db;
	$res = $db->prepare(''.$FULL_QUERY);
	//$result = $res->fetchAll(); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
	$res->execute($Array);
	$user = $res->fetch(PDO::FETCH_ASSOC);
	if($user['id'] != null){ // user_id null değilse veritabanında kayıtlı demektir
		return "logmode:{1},"/* kullanıcı veritabanında kayıtlı mı ? //1 evet dedik */."id:{".$user['id']."},"."authorization:{".$user['authorization']."},"."username:{".$user['username']."},"."password:{".$user['password']."},";
	}
}

function flexyQuery($FULL_QUERY){
	global $db;
	$res = $db->prepare(''.$FULL_QUERY);
	$res->execute();
	$number_of_rows = $res->fetchColumn(); 
	$result = $res->fetchAll(); //Sütun isimlerine ve numaralarına göre indisli bir dizi olarak:
	$return_array = $result;
	$return_array['cnt'] = $number_of_rows;
	return $return_array;
}

// How to using ? - print_r(flexyQuery_forLogin("SELECT * FROM USERS WHERE `email_sent_ok`=2"));

function selectSumInTable($TABLE,$SUMTHIS){
	global $db;
	$sum = $db->query('SELECT SUM(`'.$SUMTHIS.'`) from '.$TABLE)->fetchColumn();
	return $sum;	
}
// How to using ? - echo selectSumInTable("__daily_stats","count_daily_visits");

function selectInTable($TABLE,$SELECTQUERY,$WHERE){
	global $db;
	if($WHERE!=''){
		$query = $db->prepare('SELECT '.$SELECTQUERY.' from '.$TABLE.' WHERE '.$WHERE);
	}else{		
		$query = $db->prepare('SELECT '.$SELECTQUERY.' from '.$TABLE);
	}	
	$query->execute();
	$result = $query->fetchAll();
	return $result;	
}
function selectInTable2($FULLQUERY){
	global $db;
	$query = $db->prepare($FULLQUERY);
	$query->execute();
	$result = $query->fetchAll();
	return $result;	
}


function showTables(){
	global $db;
	$query = $db->prepare("SHOW TABLES");
	$query->execute();
	$result = $query->fetchAll(PDO::FETCH_COLUMN);
	return $result;	
}
// How to using - print_r(showTables());

function copyTable($originalTableName, $newTableName, $data){
	global $db;
	try{
		$db->exec('CREATE TABLE '.$newTableName.' LIKE '.$originalTableName);
		
		if($data=="1"){
			$db->exec('INSERT '.$newTableName.' SELECT * FROM '.$originalTableName);
		}
		
		return "1";
	}catch (PDOException $e) {
		//echo 'Connection failed: ' . $e->getMessage();
		return "2";
		//echo "data inserting problem";
	}
}
// How to using - copyTable("myTable","myNewTable",1);

function selectCountInTable($TABLE){
	global $db;
	$sql = $db->query('SELECT COUNT(*) from '.$TABLE);
	$nRows = $sql->fetchColumn();
	return $nRows;	
}
// How to using ? - print_r(selectCountInTable("users"));
	
function selectCountInTable_OptionalValues($TABLE,$WHERE){
	global $db;
	$sql = $db->query('SELECT COUNT(*) from '.$TABLE.' WHERE '.$WHERE);
	$nRows = $sql->fetchColumn();
	return $nRows;	
}
// How to using ? - print_r(selectCountInTable_OptionalValues("USERS","authority_id = '1'"));


function GetToplam($TabloAdi){
$r = $db->prepare($TabloAdi);
$r->execute();
$count = $r->fetch(PDO::FETCH_COLUMN);
return $count;
}


/*
$sth = $db->prepare("SELECT * FROM USERS");
$sth->execute();
// Sonuç kümesindeki tüm satırları alalım
print("Sonuç kümesindeki tüm satırlar:\n");
$result = $sth->fetchAll();
print_r($result);
*/
	
/*
$sth = $db->prepare("SELECT * FROM USERS");
$sth->execute();
// İlk sütunun tüm değerlerini alalım
$result = $sth->fetchAll(PDO::FETCH_COLUMN, 0);
var_dump($result);
*/
	
/*
$query = $db->query("SELECT * FROM USERS_BLOG_PROFILE WHERE user_id = {$user_id}", PDO::FETCH_ASSOC);
if ( $query->rowCount() ){
	 foreach( $query as $row ){
		echo '<url>
		<loc>http://blogexp.com/'.$row["user_blogname"].'</loc>';
	}
}
*/


/* PDOStatement::fetch tarzlarını deneyelim */

/*
print("PDO::FETCH_ASSOC:\n");
print("Sütun isimlerine göre indisli bir dizi olarak:\n");
$result = $sth->fetch(PDO::FETCH_ASSOC);
print_r($result);
print("\n");
	
print("PDO::FETCH_LAZY:\n");
echo "Her özelliğin bir sütun ismine denk düştüğü bir anonim nesne olarak:\n";
$result = $sth->fetch(PDO::FETCH_LAZY);
print_r($result);
print("\n");
	
print("PDO::FETCH_OBJ:\n");
echo "Her özelliğin bir sütun ismine denk düştüğü bir anonim nesne olarak:\n";
$result = $sth->fetch(PDO::FETCH_OBJ);
print $result->NAME;
print("\n");
*/

?>