<?php 
//Written by Mustafa YILMAZ
class Db extends PDO
{
	private $sql;
	private $array=array();
	private $son_eklenen_id;
	private $adet;
	private $error;

	public function __construct($server,$dbname,$user,$password,$charset="utf8")
	{
		try {
			parent::__construct("mysql:host={$server};dbname={$dbname};charset={$charset}",$user,$password);
			parent::setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		} catch (PDOException $e) {
			die("E: ".$e->getMessage());
		}
	}

	public function query($value)
	{
		$this->sql=$value;
		return $this;
	}

	public function data($value)
	{
		$this->array=$value;
		return $this;
	}
	public function insert()
	{
		try {
			$sorgu = parent::prepare($this->sql);
			$sorgu->execute($this->array);
			$this->son_eklenen_id=parent::lastInsertId();
			if ($this->son_eklenen_id>0){
				return true;
			}else{
				return false;
			}
			
		} catch (PDOException $e) {
			$this->error=$e->getMessage();
			return false;
		}
	}

	public function select($value="")
	{
		try {
			if ($value=="1") {
				$sorgu = parent::prepare($this->sql);
				$sorgu->execute($this->array);
				if ($sorgu->rowCount()>0) {
					$this->adet = $sorgu->rowCount();
					return $sorgu->fetch(PDO::FETCH_ASSOC);
				}else{
					return false;
				}
			}else{
				$sorgu = parent::prepare($this->sql);
				$sorgu->execute($this->array);
				if ($sorgu->rowCount()>0) {
					$this->adet = $sorgu->rowCount();
					return $sorgu->fetchAll(PDO::FETCH_ASSOC);
				}else{
					return false;
				}
			}
		}  catch (PDOException $e) {
			$this->error=$e->getMessage();
			return false;
		}
	}

	public function update()
	{
		try {
			$sorgu = parent::prepare($this->sql);
			$sorgu->execute($this->array);
			if ($sorgu->rowCount()>0){
				return true;
			}else{
				return false;
			}
			
		} catch (PDOException $e) {
			$this->error=$e->getMessage();
			return false;
		}
	}
	public function delete()
	{
		try {
			$sorgu = parent::prepare($this->sql);
			$sorgu->execute($this->array);
			if ($sorgu->rowCount()>0){
				return true;
			}else{
				return false;
			}
			
		} catch (PDOException $e) {
			$this->error=$e->getMessage();
			return false;
		}
	}
	public function getError()
	{
		return $this->error;
	}
	public function getCount()
	{
		return $this->adet;
	}
	public function sonEklenenId()
	{
		return $this->son_eklenen_id;
	}
}