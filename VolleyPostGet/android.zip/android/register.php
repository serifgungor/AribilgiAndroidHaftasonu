<?php
	//kullanıcılar tablosundaki toplam satır sayısını almak
	//echo selectCountInTable("kullanicilar");

if($_POST){
	include 'db.php';
	include 'helper/class.database.php';

	$username = $_POST["username"];
	$pass = $_POST["password"];
	$ip = "127.0.0.1";

	if($username!="" && $pass!=""){

		$user = selectCountInTable_OptionalValues("kullanicilar","username = '".$username."'");
		if($user>0){
			echo "kullanıcı sistemde zaten kayıtlıdır";
		}else{
			//veritabanına veri kaydedecek
			$response = setOptionalValues("kullanicilar","username,password,ip","'".$username."','".$pass."','".$ip."'");
			if($response==1){
				echo "kayıt başarılı";
			}else if($response==2){
				echo "kayıt işlemi sırasında hata oluştu";
			}

		}

	}else{
		echo "kullanıcı adı veya şifre boş geçilemez";
	}
}else{
	echo "istek başarısız";
}

?>