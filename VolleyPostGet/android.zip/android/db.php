<?php

    $db_host = "localhost";
    $db_name = "android";
    $db_user = "root";
    $db_pass = ""; 

?>