<?php

if($_POST){
	echo $_POST["username"]." ".$_POST["password"];
}

?>