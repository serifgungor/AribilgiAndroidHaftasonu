package com.kadirgungor.volleypostget;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    RequestQueue queue;
    StringRequest request;

    EditText etUserName;
    EditText etUserPassword;
    Button btnLogin,btnRegister;
    TextView tvMessage;

    public void init(){
        etUserName = findViewById(R.id.etUserName);
        etUserPassword = findViewById(R.id.etUserPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        tvMessage = findViewById(R.id.tvMessage);
    }

    public void islemGerceklestir(String islem){
        String islemUrl = "";
        if("login".equals(islem)){
            islemUrl = "http://192.168.64.1/android/login.php";
        }else if("register".equals(islem)){
            islemUrl = "http://192.168.64.1/android/register.php";
        }
        queue = Volley.newRequestQueue(getApplicationContext());
        request = new StringRequest(
                Request.Method.POST,
                islemUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if("login".equals(islem)){
                            tvMessage.setText(response);
                        }else if("register".equals(islem)){
                            tvMessage.setText(response);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> params = new HashMap<>();
                params.put("username",etUserName.getText().toString());
                params.put("password",etUserPassword.getText().toString());
                return params;
            }
        };
        queue.add(request);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                islemGerceklestir("register");
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                islemGerceklestir("login");
            }
        });

    }
}