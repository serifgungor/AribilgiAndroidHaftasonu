package com.roomkutuphanesi.Model;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface KisiDao {
    @Query("select * from tablo_kisi")
    List<Kisi> listKisiler();

    @Insert
    void addKisi(Kisi kisi);

    @Update
    void updateKisi(Kisi kisi);

    @Delete
    void deleteKisi(Kisi kisi);
}
