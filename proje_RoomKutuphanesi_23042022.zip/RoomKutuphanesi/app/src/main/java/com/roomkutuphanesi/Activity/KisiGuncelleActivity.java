package com.roomkutuphanesi.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.roomkutuphanesi.Model.AppDatabase;
import com.roomkutuphanesi.Model.Kisi;
import com.roomkutuphanesi.R;

public class KisiGuncelleActivity extends AppCompatActivity {

    EditText etAdGuncelle,etSoyadGuncelle,etGsmGuncelle,etNotGuncelle;
    Button btnKisiGuncelle;
    Kisi kisi;
    AppDatabase db;

    public void init(){
        this.setTitle("Kişiyi Güncelle");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        kisi = (Kisi)getIntent().getSerializableExtra("kisi");

        etAdGuncelle = findViewById(R.id.etAdGuncelle);
        etSoyadGuncelle = findViewById(R.id.etSoyadGuncelle);
        etGsmGuncelle = findViewById(R.id.etGsmGuncelle);
        etNotGuncelle = findViewById(R.id.etNotGuncelle);
        btnKisiGuncelle = findViewById(R.id.btnKisiGuncelle);

        etAdGuncelle.setText(kisi.ad);
        etSoyadGuncelle.setText(kisi.soyad);
        etGsmGuncelle.setText(kisi.gsm);
        etNotGuncelle.setText(kisi.not);

        btnKisiGuncelle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    kisi.ad = etAdGuncelle.getText().toString();
                    kisi.not = etNotGuncelle.getText().toString();
                    kisi.gsm = etGsmGuncelle.getText().toString();
                    kisi.soyad = etSoyadGuncelle.getText().toString();
                    db.kisiDao().updateKisi(kisi);
                    Toast.makeText(getApplicationContext(), "Veri güncellendi", Toast.LENGTH_SHORT).show();
                    finish();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Veri güncellenemedi", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kisi_guncelle);

        db =
                Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"kisiler")
                        .allowMainThreadQueries()
                        .fallbackToDestructiveMigration()
                        .build();

        init();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}