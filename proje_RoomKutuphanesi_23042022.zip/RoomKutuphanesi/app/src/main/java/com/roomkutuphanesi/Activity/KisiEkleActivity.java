package com.roomkutuphanesi.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.roomkutuphanesi.Model.AppDatabase;
import com.roomkutuphanesi.Model.Kisi;
import com.roomkutuphanesi.R;

public class KisiEkleActivity extends AppCompatActivity {

    EditText etAd,etSoyad,etNot,etGsm;
    Button btnKisiKaydet;
    AppDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kisi_ekle);

        this.setTitle("Kişi Ekle");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        db =
                Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"kisiler")
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build();


        etAd = findViewById(R.id.etAd);
        etSoyad = findViewById(R.id.etSoyad);
        etNot = findViewById(R.id.etNot);
        etGsm = findViewById(R.id.etGsm);
        btnKisiKaydet = findViewById(R.id.btnKisiKaydet);
        btnKisiKaydet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    Kisi kisi = new Kisi();
                    kisi.ad = etAd.getText().toString();
                    kisi.soyad = etSoyad.getText().toString();
                    kisi.gsm = etGsm.getText().toString();
                    kisi.not = etNot.getText().toString();
                    db.kisiDao().addKisi(kisi); //veritabanına veri ekler

                    Toast.makeText(getApplicationContext(), "Kişi eklendi", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Kişi eklenirken bir sorun oluştu", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}