package com.roomkutuphanesi.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.roomkutuphanesi.Model.AppDatabase;
import com.roomkutuphanesi.Model.Kisi;
import com.roomkutuphanesi.R;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listviewKisiler;
    AppDatabase db;
    ArrayAdapter<Kisi> arrayAdapter;
    List<Kisi> kisiler;

    public void init(){
        this.setTitle("Rehberim");
        listviewKisiler = findViewById(R.id.listviewKisiler);
        listviewKisiler.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setMessage("İşlem seçiniz");
                adb.setNeutralButton("İptal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        dialogInterface.dismiss();
                    }
                });
                adb.setNegativeButton("Sil", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        //veriyi silme kodu

                        Kisi kisi = kisiler.get(i);
                        db.kisiDao().deleteKisi(kisi);
                        veriyukle();


                    }
                });
                adb.setPositiveButton("Güncelle", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i2) {
                     //intent

                        Intent intent = new Intent(getApplicationContext(),KisiGuncelleActivity.class);
                        intent.putExtra("kisi",kisiler.get(i));
                        startActivityForResult(intent,10);


                    }
                });
                adb.setCancelable(false);
                adb.create();
                adb.show();


                return false;
            }
        });


    }

    public void veriyukle(){
        db =
                Room.databaseBuilder(getApplicationContext(),AppDatabase.class,"kisiler")
                        .allowMainThreadQueries()
                        .fallbackToDestructiveMigration()
                        .build();

        kisiler = db.kisiDao().listKisiler();
        arrayAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,kisiler);

        listviewKisiler.setAdapter(arrayAdapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        veriyukle();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.id_ekle){
            startActivityForResult(new Intent(getApplicationContext(),KisiEkleActivity.class),4);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==4 || requestCode==10){
            veriyukle();
        }
    }
}