package com.example.yemekapponline.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.yemekapponline.R;

public class RecipeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
    }
}