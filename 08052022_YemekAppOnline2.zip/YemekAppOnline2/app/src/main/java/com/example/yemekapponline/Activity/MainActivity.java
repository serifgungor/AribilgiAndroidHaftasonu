package com.example.yemekapponline.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.yemekapponline.Adapter.CategoryAdapter;
import com.example.yemekapponline.Model.Kategori;
import com.example.yemekapponline.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseReference myRef;
    ListView listViewKategoriler;
    ArrayList<Kategori> kategoriler;
    CategoryAdapter ca;
    public void init(){
        myRef = FirebaseDatabase.getInstance().getReference();
        kategoriler = new ArrayList<>();
        listViewKategoriler = findViewById(R.id.listViewKategoriler);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        ca = new CategoryAdapter(kategoriler,getApplicationContext());
        listViewKategoriler.setAdapter(ca);
    }
}