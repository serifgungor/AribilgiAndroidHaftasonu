package com.example.yemekapponline.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.yemekapponline.Model.Kategori;
import com.example.yemekapponline.R;

import java.util.ArrayList;

public class CategoryAdapter  extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private ArrayList<Kategori> kategoriler;
    private Context context;

    public CategoryAdapter(){}
    public CategoryAdapter(ArrayList<Kategori> kategoriler,Context context){
        this.kategoriler = kategoriler;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return kategoriler.size();
    }

    @Override
    public Kategori getItem(int position) {
        return kategoriler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.categori_row,null);
        TextView tvKategori = v.findViewById(R.id.tvCategory);
        ImageView ivKategori = v.findViewById(R.id.ivCategory);

        tvKategori.setText(kategoriler.get(position).getBaslik());
        Glide.with(context).load(kategoriler.get(position).getGorsel()).into(ivKategori);

        return v;
    }
}
