package com.example.yemekapponline.Model;

import java.io.Serializable;

public class Kategori implements Serializable {
    public String baslik;
    public String gorsel;

    public Kategori() {
    }

    public Kategori(String baslik, String gorsel) {
        this.baslik = baslik;
        this.gorsel = gorsel;
    }

    public String getBaslik() {
        return baslik;
    }

    public void setBaslik(String baslik) {
        this.baslik = baslik;
    }

    public String getGorsel() {
        return gorsel;
    }

    public void setGorsel(String gorsel) {
        this.gorsel = gorsel;
    }
}
