package com.example.yemekapponline.Model;

import java.io.Serializable;

public class Kullanici implements Serializable {
    public String username;
    public String sifre;
    public String email;
}
