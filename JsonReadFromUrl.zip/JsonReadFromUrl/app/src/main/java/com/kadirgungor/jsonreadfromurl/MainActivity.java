package com.kadirgungor.jsonreadfromurl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.kadirgungor.jsonreadfromurl.Model.Ogrenci;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RequestQueue queue;
    ArrayList<Ogrenci> ogrenciler = new ArrayList<>();
    ArrayAdapter<Ogrenci> ogrAdapter;
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        queue = new Volley().newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(
                Request.Method.GET,
                "https://raw.githubusercontent.com/serifgungor/AribilgiAndroidHaftasonu/main/ogrenciler.json",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Log.d("WEB",response);

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray ogr = jsonObject.optJSONArray("ogrenciler");
                            for (int i = 0; i < ogr.length(); i++) {
                                JSONObject ogrenci = ogr.getJSONObject(i);
                                String ad = ogrenci.getString("ad");
                                String soyad = ogrenci.getString("soyad");
                                int yas = ogrenci.getInt("yas");
                                ogrenciler.add(new Ogrenci(ad,soyad,yas));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        ogrAdapter = new ArrayAdapter<>(
                                getApplicationContext(),
                                android.R.layout.simple_list_item_1,
                                ogrenciler
                        );
                        listView.setAdapter(ogrAdapter);


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }
        );
        queue.add(request);

    }
}