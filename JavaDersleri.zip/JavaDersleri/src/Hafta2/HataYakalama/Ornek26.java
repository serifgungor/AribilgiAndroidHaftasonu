package Hafta2.HataYakalama;

public class Ornek26 {
    public static void main(String[] args) {
//ArrayIndexOutOfBoundsException dizinin olmayan indisine erişilmeye çalışındığında

        String[] dizi = new String[3];
        dizi[0]="abc";
        dizi[1]="dfg";
        dizi[2]="hij";

        try {
            System.out.println(dizi[3]);
        }catch (ArrayIndexOutOfBoundsException e){
            System.out.println("Dizinin olmayan indisine erişmeye çalıştınız");
        }

    }
}
