package Hafta2.HataYakalama;

public class Ornek24 {
    public static void main(String[] args) {

        try{
            int sayi1 = 10;
            int sayi2 = 0;
            int sonuc = sayi1/sayi2;
            //System.out.println(sonuc);
        }catch (ArithmeticException e){
            //e.printStackTrace(); - hatanın full metnini bastırır
            System.out.println(e.getMessage()); // hata metnini döndürür
        }

    }
}
