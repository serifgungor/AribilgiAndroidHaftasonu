package Hafta2.HataYakalama;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Ornek25 {
    public void dosyaIceriginiOku() throws IOException  {

    }

    public static void main(String[] args) {

        Ornek25 o = new Ornek25();

        try {
            o.dosyaIceriginiOku();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
