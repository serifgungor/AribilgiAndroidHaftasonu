package Hafta2;

import java.util.Scanner;

public class Ornek13 {
    public static void main(String[] args) {

        //Scanner sc = new Scanner(System.in);

        //birer birer arttırma
        /*
        for(int s=1; s<=10; s++){
            System.out.println(s);
        }
        */
        // n n arttırma, n = n+5,   i+=n
        /*
        for (int i = 0; i <= 50; i+=5) {
            System.out.println(i);
        }
        */

        //azaltma
        /*
        for (int i = 10; i >= 0; i--) {
            System.out.println(i);
        }
        */

        /*
        int sayi = 0;
        for (; ;) {
            sayi++;
            System.out.println("merhaba");
            if(sayi==10){
                break;
            }
        }
         */

        //continue ile atlama
        /*
        for (int i = 1; i <=5; i++) {
            if(i==3){
                continue;
            }
            System.out.println(i);
        }*/

        /*
        for (int i = 5; i <= 500; i*=2) {
            System.out.println(i);
        }
        */

        /*
        for (int i = 100; i >0 ; i/=2) {
            System.out.println(i);
        }*/


        





    }
}
