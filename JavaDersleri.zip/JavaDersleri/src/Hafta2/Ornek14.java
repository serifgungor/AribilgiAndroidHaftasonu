package Hafta2;

public class Ornek14 {

    public static void main(String[] args) {

        String[] ogrenciler = new String[4];

        ogrenciler[0]="şerif";
        ogrenciler[1]="hamza";
        ogrenciler[2]="umut";
        ogrenciler[3]="kaan";

        System.out.println(ogrenciler[1]);

        int[] sayilar = new int[2];
        sayilar[0] = 75;
        sayilar[1] = 500;
        System.out.println(sayilar[0]);

        /*
        for (int i = 0; i < ogrenciler.length; i++) {
            System.out.println(ogrenciler[i]);
        }*/

    }
}
