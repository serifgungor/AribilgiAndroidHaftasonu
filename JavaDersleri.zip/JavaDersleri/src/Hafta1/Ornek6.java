package Hafta1;

public class Ornek6 {
    public static void main(String[] args) {
        //Mutlu muyum ?
        boolean mood = false;

        if(mood){
            System.out.println("Mutluyum");
        }else{
            System.out.println("Mutsuzum");
        }
    }
}
