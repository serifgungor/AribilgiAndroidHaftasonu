package Hafta1;

public class Ornek1 {

    public static void main(String[] args) {

        int sayi = 154647455;
        short s = 32000;
        char harf = 'A';
        long l = 111111111111l;
        double d = 10.4d;
        float f = 10.7f;
        String yazi = "merhaba";
        boolean b = true;
        byte by = -10;


        System.out.println(sayi);
        System.out.println(s);
        System.out.println(harf);
        System.out.println(l);
        System.out.println(d);
        System.out.println(f);
        System.out.println(yazi);
        System.out.println(b);
        System.out.println(by);

        System.out.println(sayi + d);


    }

}