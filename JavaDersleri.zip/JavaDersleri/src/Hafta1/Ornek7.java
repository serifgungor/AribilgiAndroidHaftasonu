package Hafta1;

import java.util.Scanner;

public class Ornek7 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Adınızı giriniz");
        String adiniz = sc.next();
        System.out.println("Soyadınızı giriniz");
        String soyadiniz = sc.next();

        System.out.println("ADINIZ: "+adiniz);
        System.out.println("SOYADINIZ: "+soyadiniz);

    }
}
