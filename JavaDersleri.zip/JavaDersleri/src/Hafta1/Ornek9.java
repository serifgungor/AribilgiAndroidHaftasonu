package Hafta1;

import java.util.Scanner;

public class Ornek9 {
    public static void main(String[] args) {
        /*
        Dışarıdan kişinin adını soyadını alın değişkenlerde saklayın.
        Kişinin yaşını isteyin.
        Kişinin yaşı 20'den büyükse;
        - Yaşınız yirmiden büyüktür, değilse yaşınız yirmiden küçüktür.
        yazdırın.
         */


        Scanner sc = new Scanner(System.in);

        System.out.println("Adınızı giriniz");
        String ad = sc.next();

        System.out.println("Soyadınızı giriniz");
        String soyad = sc.next();

        System.out.println("Yaşınızı giriniz");
        int yas = sc.nextInt();

        if(yas>20){
            System.out.println("Sayın "+ad+" "+soyad+", Yaşınız yirmiden büyüktür");
        }else if(yas==20){
            System.out.println("Sayın "+ad+" "+soyad+", Yaşınız yirmidir.");
        }else{
            System.out.println("Sayın "+ad+" "+soyad+", Yaşınız yirmiden büyük değildir");
        }

    }
}
