package Hafta1;

import java.util.Scanner;

public class Ornek10 {
    public static void main(String[] args) {

        /*
        Dışarıdan kullanıcı adı ve şifre isteyiniz.
        Kullanıcı adı root ve şifresi abc123 ise giriş yapsın,
        değil ise hata giriş yazsın.
         */

        Scanner sc = new Scanner(System.in);

        System.out.println("Kullanıcı adı giriniz:");
        String kullaniciAdi = sc.next();
        System.out.println("Şifre giriniz:");
        String sifre = sc.next();

        if("root".equals(kullaniciAdi) && "abc123".equals(sifre)){
            System.out.println("Başarılı giriş");
        }else{
            System.out.println("Hatalı giriş");
        }
    }
}
