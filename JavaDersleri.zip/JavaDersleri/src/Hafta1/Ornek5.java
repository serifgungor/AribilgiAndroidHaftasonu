package Hafta1;

public class Ornek5 {
    public static void main(String[] args) {
        //MANTIKSAL OPERATÖRLER

        int yas = 11;
        //YADA
        if(yas==10 || yas==20){
            System.out.println("Yaş 10 yada 20'dir.");
        }

        int kisi1Yas = 25;
        int kisi2Yas = 27;
        if(kisi1Yas==25 && kisi2Yas==27){
            System.out.println("Kişi 1 25, Kişi 2 27 yaşındadır.");
        }

        if(!(kisi1Yas==25 && kisi2Yas==27)){
            System.out.println("Kişi 1 25 değildir ve Kişi 2 27 yaşında değildır.");
        }

    }
}
