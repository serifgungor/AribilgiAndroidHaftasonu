package Hafta1;

import java.util.Scanner;

public class Ornek12 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("1-12 arası sayı giriniz");
        int ay = sc.nextInt();

        switch (ay){
            case 1:
                System.out.println("Ocak");
                break;
            case 2:
                System.out.println("Şubat");
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            case 8:
                break;
            case 9:
                break;
            case 10:
                break;
            case 11:
                break;
            case 12:
                break;
            default:
                System.out.println("1-12 aralığı dışına çıktınız");
                break;
        }

    }
}
