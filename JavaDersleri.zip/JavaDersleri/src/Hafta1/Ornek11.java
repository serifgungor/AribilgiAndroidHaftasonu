package Hafta1;

import java.util.Scanner;

public class Ornek11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Günün adını giriniz");
        String gun = sc.next();

        if("pazartesi".equalsIgnoreCase(gun)){
            System.out.println("Haftanın günü: 1");
        }else if("salı".equalsIgnoreCase(gun)){
            System.out.println("Haftanın günü: 2");
        }else if("çarşamba".equalsIgnoreCase(gun)){
            System.out.println("Haftanın günü: 3");
        }else if("perşembe".equalsIgnoreCase(gun)){
            System.out.println("Haftanın günü: 4");
        }else if("cuma".equalsIgnoreCase(gun)){
            System.out.println("Haftanın günü: 5");
        }else if("cumartesi".equalsIgnoreCase(gun)){
            System.out.println("Haftanın günü: 6");
        }else if("pazar".equalsIgnoreCase(gun)){
            System.out.println("Haftanın günü: 7");
        }else{
            System.out.println("Hatalı değer girdiniz.");
        }

    }
}
