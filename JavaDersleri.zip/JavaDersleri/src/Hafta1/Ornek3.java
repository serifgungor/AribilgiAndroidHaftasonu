package Hafta1;

public class Ornek3 {
    public static void main(String[] args) {
        //ARİTMETİK OPERATÖRLER
        // + operatörünün toplama görevi
        int sayi1 = 7;
        int sayi2= 10;
        int sonuc = sayi1+sayi2;
        System.out.println("Toplama işlemi sonucu:"+sonuc);
        System.out.println("Çıkarma işlemi sonucu:"+(sayi1-sayi2));
        System.out.println("Çarpma işlemi sonucu:"+(sayi1*sayi2));
        System.out.println("Bölme işlemi sonucu:"+(sayi1/sayi2));
        System.out.println("Mod alma işlemi sonucu:"+(sayi1%sayi2));

        int s = 10;
        System.out.println("s:"+s);

        System.out.println("s:"+(++s));
        //++ operatörü başta olursa, önce 1 arttırır sonra yazdırır
        System.out.println("s:"+(s++));
        //++ operatörü sonda olursa, değişken değerini yazdırır sonra 1 arttırır.

        System.out.println("s - 1: "+(--s));
        System.out.println("s - 1: "+(s--));
        System.out.println("s - 1:"+s);

        System.out.println(s);


        int sayi = 25;
        int sayiSonuc = sayi++;
        sayiSonuc = sayi+=1;

        sayiSonuc = sayi--;
        sayiSonuc = sayi-=1;
        sayi = sayi +1;

        // + operatörünün birleştirme görevi
        String metin = "yaşınız";
        int yas = 30;
        System.out.println(metin+yas);


        int mod = 6;
        int modSonuc = mod%2;

        int b1 = 10;
        int b2 = 5;
        int bolmeSonuc = b1/b2;
        int carpmaSonuc = b1/b2;
        System.out.println(bolmeSonuc);
        System.out.println(carpmaSonuc);


    }
}
