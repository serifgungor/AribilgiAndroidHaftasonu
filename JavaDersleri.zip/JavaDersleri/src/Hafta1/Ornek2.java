package Hafta1;

public class Ornek2 {
    public static void main(String[] args) {


        //BİLİNÇSİZ TÜR DÖNÜŞÜMÜ
        int sayi = 5;
        double sayi2 = 10.4;
        int sonuc = (int) (sayi+sayi2);
        System.out.println(sonuc);

        //BİLİNÇLİ TÜR DÖNÜŞÜMÜ

        double d1 = 2.5;
        float f1 = 5.8f;
        double sonucf = d1+f1;


        String yil = "2022";

        int iyil = Integer.parseInt(yil);
        double dyil = Double.parseDouble(yil);
        System.out.println(dyil);

    }
}
