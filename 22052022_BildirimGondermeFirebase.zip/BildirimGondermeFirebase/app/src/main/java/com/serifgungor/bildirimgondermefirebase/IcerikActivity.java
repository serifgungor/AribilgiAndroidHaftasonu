package com.serifgungor.bildirimgondermefirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class IcerikActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_icerik);
    }
}