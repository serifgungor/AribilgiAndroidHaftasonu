package com.serifgungor.bildirimgondermefirebase;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class MyFirebaseInstanceIDService extends FirebaseMessagingService {
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        Log.d("mesaj",message.toString());


        String notificationText = message.getNotification().getBody();//Bildirimin İçerik Yazısı
        String notificationTitle = message.getNotification().getTitle();
        Uri notificationUri = message.getNotification().getImageUrl();
        //String notificationChannel = message.getNotification().getChannelId();

        Map<String,String> bildirimVerisi = message.getData();
        Log.d("getdata",bildirimVerisi.toString());


        try {
            bildirimGonder("deneme",notificationTitle,notificationText,notificationUri);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    public void bildirimGonder(String bildirimKanalAdi,String bildirimBaslik,String bildirimIcerik,Uri bildirimResim) throws IOException {

        NotificationChannel channel = new NotificationChannel(bildirimKanalAdi,
                bildirimKanalAdi, NotificationManager.IMPORTANCE_DEFAULT);
        channel.enableVibration(true);
        InputStream in = new URL(bildirimResim.toString()).openStream();
        Bitmap bmp = BitmapFactory.decodeStream(in);
        int NOTIFICATION_ID = 52;//Notification id si, channel ile ilgisi bulunmuyor
        Notification notification = new Notification.Builder(this, bildirimKanalAdi)
                .setContentTitle(bildirimBaslik)
                .setContentText(bildirimIcerik)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setStyle(new Notification.BigPictureStyle()
                        .bigPicture(bmp))
                .setAutoCancel(true)
                .build();

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.createNotificationChannel(channel);
        manager.notify(NOTIFICATION_ID, notification);
    }

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);

        Log.d("token",token);
    }
}
