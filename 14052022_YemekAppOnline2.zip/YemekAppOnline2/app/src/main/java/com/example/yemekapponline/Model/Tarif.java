package com.example.yemekapponline.Model;

import java.io.Serializable;

public class Tarif implements Serializable {
    public String baslik;
    public String username;
    public String yapilisi;
    public String resim;
    public String pisirme_suresi;
    public String malzemeleri;
    public String kisi_sayisi;
    public String hazirlanma_suresi;
    public String alerjenler;
    public String kategoriBaslik;
}
