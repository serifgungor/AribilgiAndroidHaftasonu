package com.example.yemekapponline.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.yemekapponline.Model.Kategori;
import com.example.yemekapponline.Model.Tarif;
import com.example.yemekapponline.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class RecipeActivity extends AppCompatActivity {

    Kategori kategori;
    ArrayList<Tarif> tarifler;
    DatabaseReference dbRef;

    public void tarifleriGetir(){
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                tarifler.clear();
                for(DataSnapshot sn:snapshot.getChildren()){

                    Tarif tarif = sn.getValue(Tarif.class);
                    if(kategori.baslik.equals(tarif.kategoriBaslik)){
                        tarifler.add(tarif);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    public void init(){
        tarifler = new ArrayList<>();
        kategori = (Kategori) getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.baslik);
        dbRef = FirebaseDatabase.getInstance().getReference("tarifler");
        tarifleriGetir();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        init();
    }
}