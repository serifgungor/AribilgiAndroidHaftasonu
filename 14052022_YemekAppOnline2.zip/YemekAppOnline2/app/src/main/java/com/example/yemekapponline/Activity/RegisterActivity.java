package com.example.yemekapponline.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.yemekapponline.Model.Kullanici;
import com.example.yemekapponline.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    EditText etRegisterPassword,etRegisterUsername,etRegisterEmail;
    Button btnRegisterNow;
    DatabaseReference dbRef;

    public void init(){
        dbRef = FirebaseDatabase.getInstance().getReference("kullanicilar");
        etRegisterPassword = findViewById(R.id.etRegisterPassword);
        etRegisterUsername = findViewById(R.id.etRegisterUsername);
        etRegisterEmail = findViewById(R.id.etRegisterEmail);
        btnRegisterNow = findViewById(R.id.btnRegisterNow);
        btnRegisterNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Kullanici k = new Kullanici();
                k.email = etRegisterEmail.getText().toString();
                k.sifre = etRegisterPassword.getText().toString();
                k.username = etRegisterUsername.getText().toString();

                dbRef.push().setValue(k);

                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                intent.putExtra("kullanici",k);
                startActivity(intent);
                finish();
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        init();
    }
}