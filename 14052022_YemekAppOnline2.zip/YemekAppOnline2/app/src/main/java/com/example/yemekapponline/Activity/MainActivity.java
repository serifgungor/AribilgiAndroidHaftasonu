package com.example.yemekapponline.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.yemekapponline.Adapter.CategoryAdapter;
import com.example.yemekapponline.Model.Kategori;
import com.example.yemekapponline.Model.Kullanici;
import com.example.yemekapponline.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseReference myRef;
    ListView listViewKategoriler;
    ArrayList<Kategori> kategoriler;
    CategoryAdapter ca;
    Gson gson;
    Kullanici kullanici;
    LinearLayout linearYetki;

    public void kategorileriGetir(){
        myRef.child("kategoriler").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                kategoriler.clear();
                for (DataSnapshot sn:snapshot.getChildren()) {
                    String kategoriJson = sn.getValue().toString();
                    Kategori k = sn.getValue(Kategori.class);
                    kategoriler.add(k);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }


    public void init(){
        linearYetki = findViewById(R.id.linearYetki);
        kullanici = (Kullanici) getIntent().getSerializableExtra("kullanici");

        if("100".equals(kullanici.yetki)){
            Button btnKategoriEkle = new Button(getApplicationContext());
            btnKategoriEkle.setText("Kategori Ekle");
            btnKategoriEkle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
            linearYetki.addView(btnKategoriEkle);
        }


        gson = new Gson();
        myRef = FirebaseDatabase.getInstance().getReference();
        kategoriler = new ArrayList<>();
        listViewKategoriler = findViewById(R.id.listViewKategoriler);
        kategorileriGetir();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        ca = new CategoryAdapter(kategoriler,getApplicationContext());
        listViewKategoriler.setAdapter(ca);
        listViewKategoriler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),RecipeActivity.class);
                intent.putExtra("kategori",kategoriler.get(position));
                startActivity(intent);
            }
        });
    }
}