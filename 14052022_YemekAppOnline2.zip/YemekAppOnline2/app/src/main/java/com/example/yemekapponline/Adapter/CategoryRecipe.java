package com.example.yemekapponline.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.example.yemekapponline.Model.Tarif;

import java.util.ArrayList;

public class CategoryRecipe extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Tarif> tarifler;

    public CategoryRecipe() {
    }

    public CategoryRecipe(Context context, ArrayList<Tarif> tarifler) {
        this.context = context;
        this.tarifler = tarifler;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }
}
