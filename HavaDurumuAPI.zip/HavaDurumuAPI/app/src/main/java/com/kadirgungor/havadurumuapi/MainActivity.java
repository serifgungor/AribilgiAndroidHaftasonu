package com.kadirgungor.havadurumuapi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Spinner spSehir;
    ImageView ivIcon;
    TextView tvHumidity, tvCloud, tvCountryName, tvCityName, tvDay, tvCelcius, tvFahrein, tvConditionText;
    ArrayList<String> sehirler = new ArrayList<>();
    ArrayAdapter<String> arrayAdapter;

    RequestQueue queue;
    StringRequest request;


    public void init() {
        ivIcon = findViewById(R.id.ivIcon);
        spSehir = findViewById(R.id.spSehir);
        tvHumidity = findViewById(R.id.tvHumidity);
        tvCloud = findViewById(R.id.tvCloud);
        tvCountryName = findViewById(R.id.tvCountryName);
        tvCityName = findViewById(R.id.tvCityName);
        tvDay = findViewById(R.id.tvDay);
        tvCelcius = findViewById(R.id.tvCelcius);
        tvFahrein = findViewById(R.id.tvFahrein);
        tvConditionText = findViewById(R.id.tvConditionText);
    }

    public void sehirleriDoldur() {
        sehirler.add("-");
        sehirler.add("Istanbul");
        sehirler.add("Ankara");
        sehirler.add("Bursa");
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        sehirleriDoldur();
        arrayAdapter = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                sehirler
        );
        spSehir.setAdapter(arrayAdapter);

        spSehir.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (!"-".equals(sehirler.get(i))) {
                    queue = Volley.newRequestQueue(getApplicationContext());
                    request = new StringRequest(
                            Request.Method.GET,
                            "http://api.weatherapi.com/v1/current.json?key=6f4d70771e8c4c43ae2155549220801&q=" + spSehir.getSelectedItem().toString() + "&aqi=no",
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {

                                    Log.d("ws", response);
                                    try {
                                        JSONObject jsonObject = new JSONObject(response);
                                        JSONObject location = jsonObject.getJSONObject("location");
                                        JSONObject current = jsonObject.getJSONObject("current");

                                        tvCountryName.setText(location.getString("country"));
                                        tvCityName.setText(location.getString("region"));
                                        tvDay.setText(""+current.getInt("is_day"));
                                        tvHumidity.setText(""+current.getInt("humidity"));
                                        tvCloud.setText(""+current.getInt("cloud"));
                                        tvCelcius.setText(""+current.getInt("temp_c"));
                                        tvFahrein.setText(""+current.getInt("temp_f"));

                                        JSONObject condition = current.getJSONObject("condition");
                                        tvConditionText.setText(condition.getString("text"));

                                        Glide.with(getApplicationContext()).load("http:"+condition.getString("icon")).into(ivIcon);

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {

                                }
                            }
                    );
                    queue.add(request);

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        //http://api.weatherapi.com/v1/current.json?key=6f4d70771e8c4c43ae2155549220801&q=Istanbul&aqi=no
    }
}