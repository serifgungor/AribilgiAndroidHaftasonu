package com.kadirgungor.notdefterisqlite.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.kadirgungor.notdefterisqlite.Model.Notes;
import com.kadirgungor.notdefterisqlite.R;

import java.util.ArrayList;

public class NoteListAdapter extends BaseAdapter {
    private ArrayList<Notes> notes;
    private Context context;
    private LayoutInflater layoutInflater;

    public NoteListAdapter(){}

    public NoteListAdapter(Context context,ArrayList<Notes> notes){
        this.notes = notes;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return notes.size();
    }

    @Override
    public Notes getItem(int i) {
        return notes.get(i);
    }

    @Override
    public long getItemId(int i) {
        return notes.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = layoutInflater.inflate(R.layout.note_row,null);
        TextView tvNoteTitle = v.findViewById(R.id.tvNoteTitle);
        TextView tvNoteDate = v.findViewById(R.id.tvNoteDate);

        tvNoteDate.setText(""+notes.get(i).getDate());
        tvNoteTitle.setText(notes.get(i).getTitle());

        return v;
    }
}
