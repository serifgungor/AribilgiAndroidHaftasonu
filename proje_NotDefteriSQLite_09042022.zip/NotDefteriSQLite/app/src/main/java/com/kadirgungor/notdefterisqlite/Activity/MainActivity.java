package com.kadirgungor.notdefterisqlite.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.kadirgungor.notdefterisqlite.Adapter.NoteListAdapter;
import com.kadirgungor.notdefterisqlite.Helper.DatabaseHelper;
import com.kadirgungor.notdefterisqlite.Model.Notes;
import com.kadirgungor.notdefterisqlite.R;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper dbHelper;
    SQLiteDatabase db;
    ListView listViewNotlar;
    NoteListAdapter adapter;
    ArrayList<Notes> notes = new ArrayList<>();

    public void init(){
        listViewNotlar = findViewById(R.id.listViewNotlar);
    }

    public ArrayList<Notes> getNotes(){
        //Veritabanından gelen Notes tablosundaki verilerin çekilmesi için kullanılacak
        ArrayList<Notes> notes = new ArrayList<>();
        try{
            Cursor c = db.rawQuery("select * from Notes",null);
            while (c.moveToNext()){
                @SuppressLint("Range") int id = c.getInt(c.getColumnIndex("id"));
                @SuppressLint("Range") String title = c.getString(c.getColumnIndex("title"));
                @SuppressLint("Range") String date = c.getString(c.getColumnIndex("date"));
                @SuppressLint("Range") String content = c.getString(c.getColumnIndex("content"));
                notes.add(new Notes(id,title,date,content));
            }
        }catch (Exception e){}
        this.notes = notes;
        return notes;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Notlarım");
        init();

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();

            adapter = new NoteListAdapter(getApplicationContext(),getNotes());
            listViewNotlar.setAdapter(adapter);

        } catch (IOException e) {
            e.printStackTrace();
        }

        listViewNotlar.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("İşlem seçiniz");
                adb.setMessage("Lütfen bir işlem seçiniz");
                adb.setNeutralButton("İptal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                adb.setPositiveButton("Güncelle", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        Intent intent = new Intent(getApplicationContext(),NoteAddActivity.class);
                        intent.putExtra("islem","veriguncelle");
                        intent.putExtra("veri",notes.get(i));
                        startActivityForResult(intent,50);
                    }
                });
                adb.setNegativeButton("Görüntüle", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i2) {
                        Intent intent = new Intent(getApplicationContext(),NoteAddActivity.class);
                        intent.putExtra("islem","verigoruntule");
                        intent.putExtra("veri",notes.get(i));
                        startActivityForResult(intent,50);
                    }
                });
                adb.create();
                adb.show();


                return false;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //Menüyü Toolbar'a bağlar
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //Menu elemanının tıklanma olayını yakalar.
        if(item.getItemId()==R.id.id_notekle){
            Intent intent = new Intent(getApplicationContext(),NoteAddActivity.class);
            intent.putExtra("islem","veriekle");
            startActivityForResult(intent,50);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //NoteAddActivity sayfası kapatılıp MainActivity sayfasına geri dönüldüyse
        if(requestCode==50){
            adapter = new NoteListAdapter(getApplicationContext(),getNotes());
            listViewNotlar.setAdapter(adapter);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}