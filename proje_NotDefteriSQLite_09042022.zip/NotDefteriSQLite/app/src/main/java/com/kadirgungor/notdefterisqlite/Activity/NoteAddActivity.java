package com.kadirgungor.notdefterisqlite.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.kadirgungor.notdefterisqlite.Helper.DatabaseHelper;
import com.kadirgungor.notdefterisqlite.Model.Notes;
import com.kadirgungor.notdefterisqlite.R;

import java.io.IOException;

public class NoteAddActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    SQLiteDatabase db;

    EditText etBaslik,etTarih,etIcerik;
    Button btnNotOlustur;

    String islem;
    Notes note;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_add);

        //Toolbar'a geri git butonunu ekler
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        etBaslik = findViewById(R.id.etBaslik);
        etTarih = findViewById(R.id.etTarih);
        etIcerik = findViewById(R.id.etIcerik);
        btnNotOlustur = findViewById(R.id.btnNotEkle);

        islem = getIntent().getStringExtra("islem");
        if(getIntent().getSerializableExtra("veri")!=null){
            note = (Notes) getIntent().getSerializableExtra("veri");
            etBaslik.setText(note.getTitle());
            etTarih.setText(note.getTitle());
            etIcerik.setText(note.getContent());
        }

        if("verigoruntule".equals(islem)){
            setTitle("Not Görüntüleme");
            btnNotOlustur.setText("Notu Sil");
        }else if("veriguncelle".equals(islem)){
            setTitle("Notu Güncelle");
            btnNotOlustur.setText("Notu Güncelle");
        }else if("veriekle".equals(islem)){
            setTitle("Not Ekle");
            btnNotOlustur.setText("Notu Oluştur");
        }

        try {
            dbHelper = new DatabaseHelper(getApplicationContext());
            db = dbHelper.getReadableDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }


        btnNotOlustur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if("veriekle".equals(islem)){
                    ContentValues cv = new ContentValues();
                    cv.put("title",etBaslik.getText().toString());
                    cv.put("date",etTarih.getText().toString());
                    cv.put("content",etIcerik.getText().toString());
                    db.insert("Notes",null,cv);

                    Toast.makeText(getApplicationContext(), "Not Oluşturuldu", Toast.LENGTH_SHORT).show();
                    etBaslik.setText("");
                    etTarih.setText("");
                    etIcerik.setText("");
                }else if("veriguncelle".equals(islem)){
                    ContentValues cv = new ContentValues();
                    cv.put("title",etBaslik.getText().toString());
                    cv.put("date",etTarih.getText().toString());
                    cv.put("content",etIcerik.getText().toString());
                    db.update("Notes",cv,"id = ?",new String[]{String.valueOf(note.getId())});
                    finish();
                }else if("verigoruntule".equals(islem)){
                    //Veri sil butonuna tıklanırsa
                    db.delete("Notes","id = ?",new String[]{String.valueOf(note.getId())});
                    finish();
                }

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}