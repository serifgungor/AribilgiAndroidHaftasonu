package com.example.mvvm_paging3.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;

import android.os.Bundle;

import com.example.mvvm_paging3.Adapter.FilmAdapter;
import com.example.mvvm_paging3.Adapter.FilmLoadStateAdapter;
import com.example.mvvm_paging3.R;
import com.example.mvvm_paging3.Util.FilmComparator;
import com.example.mvvm_paging3.Util.GridSpace;
import com.example.mvvm_paging3.ViewModel.MainActivityViewModel;
import com.example.mvvm_paging3.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        //setSupportActionBar(binding.toolbar);

        FilmAdapter filmAdapter = new FilmAdapter(new FilmComparator());
        MainActivityViewModel mainActivityViewModel = new ViewModelProvider(this).get(MainActivityViewModel.class);
        mainActivityViewModel.pagingDataFlowable.subscribe(filmPagingData -> {
            filmAdapter.submitData(getLifecycle(),filmPagingData);
        });

        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,2);
        binding.rvFilmler.setLayoutManager(gridLayoutManager);
        binding.rvFilmler.addItemDecoration(new GridSpace(2,20,true));
        binding.rvFilmler.setAdapter(filmAdapter.withLoadStateFooter(new FilmLoadStateAdapter(v-> {filmAdapter.retry();})));
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                return filmAdapter.getItemViewType(position) == FilmAdapter.LOADING_ITEM ? 1:2;
            }
        });


    }
}