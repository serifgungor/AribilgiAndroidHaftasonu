package com.example.mvvm_paging3.ViewModel;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import androidx.paging.Pager;
import androidx.paging.PagingConfig;
import androidx.paging.PagingData;
import androidx.paging.rxjava3.PagingRx;

import com.example.mvvm_paging3.Model.Film;
import com.example.mvvm_paging3.Paging.FilmSayfalamaKaynak;

import io.reactivex.rxjava3.core.Flowable;
import kotlinx.coroutines.CoroutineScope;

public class MainActivityViewModel extends ViewModel {
    public Flowable<PagingData<Film>> pagingDataFlowable;

    public MainActivityViewModel(){
        init();
    }

    public void init(){
        FilmSayfalamaKaynak filmSayfalamaKaynak = new FilmSayfalamaKaynak();
        Pager<Integer,Film> pager = new Pager(
                new PagingConfig(20,20,false,20,1000),() -> filmSayfalamaKaynak);
        pagingDataFlowable = PagingRx.getFlowable(pager);
        CoroutineScope coroutineScope = ViewModelKt.getViewModelScope(this);
        PagingRx.cachedIn(pagingDataFlowable,coroutineScope);

    }

}
