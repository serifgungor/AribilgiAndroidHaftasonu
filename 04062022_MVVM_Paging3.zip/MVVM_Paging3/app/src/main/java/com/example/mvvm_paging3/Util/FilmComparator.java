package com.example.mvvm_paging3.Util;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import com.example.mvvm_paging3.Model.Film;

public class FilmComparator extends DiffUtil.ItemCallback<Film> {
    @Override
    public boolean areItemsTheSame(@NonNull Film oldItem, @NonNull Film newItem) {
        return oldItem.getId().equals(newItem.getId());
    }

    @Override
    public boolean areContentsTheSame(@NonNull Film oldItem, @NonNull Film newItem) {
        return oldItem.getId().equals(newItem.getId());
    }
}
