package com.example.mvvm_paging3.Adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.paging.PagingDataAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mvvm_paging3.Model.Film;
import com.example.mvvm_paging3.databinding.FilmSatiriBinding;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

public class FilmAdapter extends PagingDataAdapter<Film,FilmAdapter.FilmViewHolder> {
    public static final int LOADING_ITEM = 0;
    public static final int FILM_ITEM = 1;

    public FilmAdapter(@NotNull DiffUtil.ItemCallback<Film> diffCallback){
        super(diffCallback);
    }

    @NonNull
    @Override
    public FilmViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new FilmViewHolder(FilmSatiriBinding.inflate(LayoutInflater.from(parent.getContext()),parent,false));
    }

    public class FilmViewHolder extends RecyclerView.ViewHolder{
        FilmSatiriBinding filmSatiriBinding;

        public FilmViewHolder(@NonNull FilmSatiriBinding b) {
            super(b.getRoot());
            this.filmSatiriBinding = b;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull FilmAdapter.FilmViewHolder holder, int position) {
        Film suankiFilm = getItem(position);
        Log.d("resim",suankiFilm.getId().toString() + "" + suankiFilm.getGorsel());
        if(suankiFilm != null){
            if(suankiFilm.getGorsel()!=null){
                Picasso
                        .get()
                        .load("https://image.tmdb.org/t/p/w500"+suankiFilm.getGorsel())
                        .fit()
                        .into(holder.filmSatiriBinding.ivResim);

            }
            holder.filmSatiriBinding.tvYuzde.setText(suankiFilm.getBegeniYuzdesi()+"");
            holder.filmSatiriBinding.tvTitle.setText(suankiFilm.getTitle());
        }

    }

    @Override
    public int getItemViewType(int position) {
        return position == getItemCount() ? FILM_ITEM : LOADING_ITEM;
    }
}
