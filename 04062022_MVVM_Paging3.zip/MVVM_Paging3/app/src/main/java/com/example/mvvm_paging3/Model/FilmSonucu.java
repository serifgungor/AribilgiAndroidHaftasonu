package com.example.mvvm_paging3.Model;

import com.example.mvvm_paging3.Model.Film;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class FilmSonucu {
    @SerializedName("page")
    @Expose
    private Integer sayfa;
    @SerializedName("results")
    @Expose
    private List<Film> filmler = null;
    @SerializedName("total_pages")
    @Expose
    private Integer toplamSayfaSayisi;
    @SerializedName("total_results")
    @Expose
    private Integer toplamSonuc;

    public Integer getSayfa() {
        return sayfa;
    }

    public void setSayfa(Integer sayfa) {
        this.sayfa = sayfa;
    }

    public List<Film> getFilmler() {
        return filmler;
    }


    public void setFilmler(List<Film> filmler) {
        this.filmler = filmler;
    }

    public int getToplamSayfaSayisi() {
        return toplamSayfaSayisi;
    }

    public void setToplamSayfaSayisi(Integer toplamSayfaSayisi) {
        this.toplamSayfaSayisi = toplamSayfaSayisi;
    }

    public int getToplamSonuc() {
        return toplamSonuc;
    }

    public void setToplamSonuc(Integer toplamSonuc) {
        this.toplamSonuc = toplamSonuc;
    }
}
