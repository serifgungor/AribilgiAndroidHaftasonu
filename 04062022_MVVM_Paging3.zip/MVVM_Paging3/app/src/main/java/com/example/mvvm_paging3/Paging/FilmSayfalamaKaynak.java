package com.example.mvvm_paging3.Paging;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.paging.PagingState;
import androidx.paging.rxjava3.RxPagingSource;

import com.example.mvvm_paging3.API.APIClient;
import com.example.mvvm_paging3.Model.Film;
import com.example.mvvm_paging3.Model.FilmSonucu;

import java.util.List;

import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class FilmSayfalamaKaynak extends RxPagingSource<Integer, Film> {
    @Nullable
    @Override
    public Integer getRefreshKey(@NonNull PagingState<Integer, Film> pagingState) {
        return null;
    }

    @NonNull
    @Override
    public Single<LoadResult<Integer, Film>> loadSingle(@NonNull LoadParams<Integer> loadParams) {
        try{
            int sayfa = loadParams.getKey() != null ? loadParams.getKey(): 1;
            return
                    APIClient.getApiInterface()
                            .getMoviesByPage(sayfa)
                            .subscribeOn(Schedulers.io())
                            .map(FilmSonucu::getFilmler)
                            .map(films -> sonucuYukle(films,sayfa))
                            .onErrorReturn(LoadResult.Error::new);
        }catch (Exception e){
            return Single.just(new LoadResult.Error(e));
        }
    }

    private LoadResult<Integer,Film> sonucuYukle(List<Film> filmler,int sayfa){
        return new LoadResult.Page(filmler,sayfa==1?null:sayfa-1,sayfa+1);
    }
}
