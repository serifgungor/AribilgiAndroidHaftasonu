package com.example.mvvm_paging3.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Objects;

public class Film {
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("poster_path")
    @Expose
    private String gorsel;
    @SerializedName("vote_average")
    @Expose
    private Double begeniYuzdesi;

    @SerializedName("original_title")
    @Expose
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGorsel() {
        return gorsel;
    }

    public void setGorsel(String gorsel) {
        this.gorsel = gorsel;
    }

    public Double getBegeniYuzdesi() {
        return begeniYuzdesi;
    }

    public void setBegeniYuzdesi(Double begeniYuzdesi) {
        this.begeniYuzdesi = begeniYuzdesi;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null) return false;
        return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, gorsel, begeniYuzdesi);
    }
}
