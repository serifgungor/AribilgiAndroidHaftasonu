package Hafta3.Sorular;

import java.util.Scanner;

public class Ornek34
{
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("Bölünen Giriniz.");
        Double bolunen = sc.nextDouble();
        System.out.println("Bölen Giriniz");
        Double bolen = sc.nextDouble();

        if(bolen==0) {
            System.out.println("Bölen 0 Olamaz");
        }else{
            double bolum = bolunen/bolen;
            System.out.println("Bölüm:"+bolum);
        }
    }


}
