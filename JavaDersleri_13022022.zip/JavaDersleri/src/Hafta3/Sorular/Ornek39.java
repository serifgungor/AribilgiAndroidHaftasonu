package Hafta3.Sorular;

import java.util.Scanner;

public class Ornek39{
    public static void main(String[] args) {
        Scanner girdi = new Scanner(System.in);
        System.out.println("Ürün Fiyatı Giriniz");
        double fiyat = girdi.nextDouble();
        double kdvli =fiyat*1.18;
        double indirimli = fiyat -(fiyat*0.18);
        System.out.println("Ürünün KDV'li Fiyatı"+kdvli);
        System.out.println("Ürünün İndirimli  Fiyatı"+indirimli);

        

    }
}
