package Hafta3.Sorular;

import java.util.Scanner;

public class Ornek33 {
    static Scanner sc;
    public static double kisaKenar = 0 ,  uzunKenar = 0 ,yariCap =  0 , kenarUzunluk= 0;
    public static void islemSecimi(Scanner sc){
        System.out.print("Yeniden hesaplama yapmak ister misiniz? \nEvet\nHayır");
        String secimS = sc.next();
        if(secimS.equalsIgnoreCase("Evet")){
            islem();
        }else if(secimS.equalsIgnoreCase("Hayır")){
            System.out.println("İşlem sonlandırıldı");
        }else{
            System.out.println("Hatalı bir işlem girildi.Tekrar işlem yapmak için evet yazınız.");
            secimS = sc.next();
            if(secimS.equalsIgnoreCase("Evet")){
                islem();
            }
        }
    }

    public static double daireCevre(){
        return yariCap * 2 * Math.PI;
    }
    public static double daireAlan(){
        return Math.PI * yariCap*yariCap;
    }
    public static double kareAlan(){
        return kenarUzunluk*kenarUzunluk;
    }
    public static double kareCevre ( ){
        return kenarUzunluk* 4 ;
    }
    public static double dikDortgenCevre (){
        return 2*(kisaKenar+uzunKenar);
    }
    public static double dikdortgenAlan (){
        return kisaKenar*uzunKenar;
    }
    public static void islem(){
        sc= new Scanner(System.in);
        System.out.println("1.daire\n2.kare\n3.dikdörtgen");
        System.out.print("Lütfen şekil seç");
        int secim = sc.nextInt();
        if(secim == 1){
            System.out.print("yarıçapı giriniz");
             yariCap = sc.nextDouble();
            System.out.println("Dairenin Çevresi="+ daireCevre());
            System.out.println("Dairenin alanı="+ daireAlan());
           islemSecimi(sc);
        }else if(secim == 2){
            System.out.print("Kenar uzunluğu giriniz=");
            kenarUzunluk = sc.nextDouble();
            System.out.println("Karenin çevresi =" + kareCevre());
            System.out.println("Karenin alanı ="+ kareAlan());
            islemSecimi(sc);
        }else if (secim ==3){
            System.out.print("Kısa kenar giriniz=");
            kisaKenar = sc.nextDouble();
            System.out.print("Uzun kenar giriniz");
            uzunKenar= sc.nextDouble();
            System.out.println("Dikdörtgenin Çevresi ="+ dikDortgenCevre());
            System.out.println("Dikdörtgenin Alan ="+ dikdortgenAlan());
            islemSecimi(sc);
        }else {
            System.out.println();
            islem();
        }



    }


    public static void main(String[] args) {
        islem();


    }
}
