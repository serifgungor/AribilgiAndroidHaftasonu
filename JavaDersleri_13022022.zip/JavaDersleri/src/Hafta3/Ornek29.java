package Hafta3;

import java.util.Scanner;

public class Ornek29 {

    public static int topla(int sayi1,int sayi2){
        return sayi1+sayi2;
    }
    public static int cikarma(int sayi1,int sayi2){
        return sayi1-sayi2;
    }
    public static int carpma(int sayi1,int sayi2){
        return sayi1*sayi2;
    }
    public static int bolme(int sayi1,int sayi2){
        return sayi1/sayi2;
    }
    public static int modalma(int sayi1,int sayi2){
        return sayi1%sayi2;
    }

    public static void islem(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Birinci sayıyı giriniz:");
        int sayi1 = sc.nextInt();
        System.out.println("İkinci sayıyı giriniz:");
        int sayi2 = sc.nextInt();
        System.out.println("İşlem seçiniz: \n1: Toplama\n2: Çıkarma\n3: Bölme\n4:Çarpma\n5: Mod alma\n6: Tümü");
        int islem = sc.nextInt();

        if(islem==1){
            System.out.println("Toplama Sonucu: "+topla(sayi1,sayi2));
        }else if(islem==2){
            System.out.println("Çıkarma Sonucu: "+cikarma(sayi1,sayi2));
        }else if(islem==3){
            System.out.println("Bölme Sonucu: "+carpma(sayi1,sayi2));
        }else if(islem==4){
            System.out.println("Çarpma Sonucu: "+bolme(sayi1,sayi2));
        }else if(islem==5){
            System.out.println("Mod Alma Sonucu: "+modalma(sayi1,sayi2));
        }else if(islem==6){
            System.out.println("Toplama Sonucu: "+topla(sayi1,sayi2));
            System.out.println("Çıkarma Sonucu: "+cikarma(sayi1,sayi2));
            System.out.println("Bölme Sonucu: "+carpma(sayi1,sayi2));
            System.out.println("Çarpma Sonucu: "+bolme(sayi1,sayi2));
            System.out.println("Mod Alma Sonucu: "+modalma(sayi1,sayi2));
        }else{
            System.out.println("Hatalı işlem....");
            islem();
        }
    }

    public static void main(String[] args) {
        islem();
        //RECURSİVE METHOD
    }

}
