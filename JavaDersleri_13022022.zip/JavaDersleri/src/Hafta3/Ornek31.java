package Hafta3;

import java.util.Scanner;

public class Ornek31 {

    public static double alan(double kenarUzunlugu){
        return kenarUzunlugu*kenarUzunlugu;
    }
    public static double cevre(double kenarUzunlugu){
        return kenarUzunlugu*4;
    }
    public static void main(String[] args) {
        // Karenin alan ve çevre hesaplamasını yapan metot üretiniz.
        Scanner sc = new Scanner(System.in);
        System.out.println("Karenin bir kenar uzunluğunu giriniz");
        double kenar = sc.nextDouble();
        System.out.println("Karenin alanı: "+alan(kenar));
        System.out.println("Karenin çevresi: "+cevre(kenar));
    }
}
