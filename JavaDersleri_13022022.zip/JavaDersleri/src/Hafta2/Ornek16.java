package Hafta2;

public class Ornek16 {
    public static void main(String[] args) {
        int tekToplam = 10;
        int ciftToplam = 20;
        for (int i = 10; i <=20 ; i++) {
            if(i%2==0){
                ciftToplam += i;
            }else{
                tekToplam += i;
            }
        }

        System.out.println("Teklerin toplamı : "+tekToplam);
        System.out.println("Çiftlerin toplamı : "+ciftToplam);
    }
}
