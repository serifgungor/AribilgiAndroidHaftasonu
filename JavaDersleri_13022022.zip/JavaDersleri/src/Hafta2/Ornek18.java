package Hafta2;

public class Ornek18 {
    public static void main(String[] args) {

        //1-10 arası sayı saymak
        for (int i = 1; i <= 10; i++) {
            //bir sayı için 10 defa dönmek
            for (int j = 1; j <=10 ; j++) {
                //belirtilen sayı için çarpma işlemi
                System.out.println(i+"*"+j+"="+(i*j));
            }
            System.out.println("------");
        }
        System.out.println("İşlem bitti");


    }
}
