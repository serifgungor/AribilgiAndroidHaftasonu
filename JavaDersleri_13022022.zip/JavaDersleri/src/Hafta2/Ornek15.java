package Hafta2;

import java.util.Scanner;

public class Ornek15 {
    public static void main(String[] args) {

        /*
        Dışarıdan 5 adet marka adı isteyin ve dizi içerisinde bunları saklayın.
        1. DÖNGÜ DEĞERLERİ İSTEMEK İÇİN
        2. DÖNGÜ DEĞERLERİ LİSTEMEK İÇİN
         */

        Scanner sc = new Scanner(System.in);
        String[] dizi = new String[5];

        for (int i = 0; i < dizi.length; i++) {
            System.out.println((i+1)+". marka adı giriniz");
            dizi[i]=sc.next();
        }

        for (int i = 0; i < dizi.length; i++) {
            System.out.println((i+1)+". marka: "+dizi[i]);
        }



    }
}
