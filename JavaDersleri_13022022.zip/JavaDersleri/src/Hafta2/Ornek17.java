package Hafta2;

public class Ornek17 {


    public static void main(String[] args) {

        String isim = "ARI BİLGİ";
        for (int i = 0; i < isim.length(); i++) {
            System.out.println(isim.charAt(i));
        }


    }
}
