package Hafta2.HataYakalama;

import java.util.Scanner;

public class Ornek27 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Adınızı giriniz");
        String isim = sc.next();
        System.out.println("Kaçıncı karaktere erişmek istiyorsunuz");
        int indis = sc.nextInt();

        if(indis>isim.length()){
            System.out.println("Dizin dışarısına çıktınız");
        }else{
            System.out.println(isim.charAt(7));
        }

        try {

        }catch (StringIndexOutOfBoundsException e){
            System.out.println("Stringin olmayan indisine erişmeye çalıştınız !");
        }
    }
}
