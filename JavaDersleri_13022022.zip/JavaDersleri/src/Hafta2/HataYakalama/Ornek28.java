package Hafta2.HataYakalama;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Ornek28 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try{
            int sayi = sc.nextInt();
            System.out.println(sayi);
            //InputMismatchException eşleşmeyen veri tipi hatası
        }catch (InputMismatchException e){
            System.out.println("Eşleşmeyen tür hatası");
        }

    }
}
