package Hafta2;

public class Ornek21 {
    public static void main(String[] args) {

        /*
        While döngüsü veritabanı işlemleri ve dosya işlemlerinde tercih edilir.
         */
        /*
        int i=0;
        while (i<=10){
            System.out.println(i);
            i++;
        }
         */
        /*
        int i=10;
        while (i>=0){
            System.out.println(i);
            i--;
        }
         */



    }
}
