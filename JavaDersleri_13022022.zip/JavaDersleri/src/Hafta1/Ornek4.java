package Hafta1;

public class Ornek4 {
    public static void main(String[] args) {
        //İLİŞKİSEL OPERATÖRLER
        int sayi1 = 5;
        int sayi2 = 5;
        if(sayi1==sayi2){
            System.out.println("Sayı1, Sayı2'ye eşittir.");
        }
        if(sayi1!=sayi2){
            System.out.println("Sayı1 değeri,Sayı2 değerine eşit değildir.");
        }
        if(sayi1>sayi2){
            System.out.println("Sayı1, sayı2'den büyüktür.");
        }
        if(sayi1<sayi2){
            System.out.println("Sayı1, sayı2'den küçüktür");
        }
        if(sayi1>=sayi2){
            System.out.println("Sayı1 değeri,Sayı2 değerine eşit yada büyüktür");
        }
        if(sayi1<=sayi2){
            System.out.println("Sayı1 değeri, Sayı2 değişken değerine eşit veya küçüktür.");
        }


    }
}
