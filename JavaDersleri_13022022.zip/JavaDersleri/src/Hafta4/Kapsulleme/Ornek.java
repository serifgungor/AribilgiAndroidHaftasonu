package Hafta4.Kapsulleme;

public class Ornek {
    public static void main(String[] args) {
//String adSoyad, String email, String telefonNo, String evAdresi, String okul, String bolum, int sinif, double ogrenciNo
        Ogrenci ogrenci = new Ogrenci(
                "şerif güngör",
                "gungoronline@gmail.com",
                "2120001122",
                "Kadıköy/İstanbul",
                "ArıBilgi Eğitim Kurumları",
                "Android/Java",
                1,
                10001
        ); //Nesne üretme
        System.out.println(ogrenci);

    }

}
