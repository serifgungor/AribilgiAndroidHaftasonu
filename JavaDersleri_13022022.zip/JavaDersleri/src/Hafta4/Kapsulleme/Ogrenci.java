package Hafta4.Kapsulleme;

public class Ogrenci {
    private String adSoyad;
    private String email;
    private String telefonNo;
    private String evAdresi;
    private String okul;
    private String bolum;
    private int sinif;
    private double ogrenciNo;

    public Ogrenci() {
    }

    public Ogrenci(String adSoyad, String email, String telefonNo, String evAdresi, String okul, String bolum, int sinif, double ogrenciNo) {
        this.adSoyad = adSoyad;
        this.email = email;
        this.telefonNo = telefonNo;
        this.evAdresi = evAdresi;
        this.okul = okul;
        this.bolum = bolum;
        this.sinif = sinif;
        this.ogrenciNo = ogrenciNo;
    }

    public String getAdSoyad() {
        return adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefonNo() {
        return telefonNo;
    }

    public void setTelefonNo(String telefonNo) {
        this.telefonNo = telefonNo;
    }

    public String getEvAdresi() {
        return evAdresi;
    }

    public void setEvAdresi(String evAdresi) {
        this.evAdresi = evAdresi;
    }

    public String getOkul() {
        return okul;
    }

    public void setOkul(String okul) {
        this.okul = okul;
    }

    public String getBolum() {
        return bolum;
    }

    public void setBolum(String bolum) {
        this.bolum = bolum;
    }

    public int getSinif() {
        return sinif;
    }

    public void setSinif(int sinif) {
        this.sinif = sinif;
    }

    public double getOgrenciNo() {
        return ogrenciNo;
    }

    public void setOgrenciNo(double ogrenciNo) {
        this.ogrenciNo = ogrenciNo;
    }

    @Override
    public String toString() {
        return "Ogrenci{" +
                "adSoyad='" + adSoyad + '\'' +
                ", email='" + email + '\'' +
                ", telefonNo='" + telefonNo + '\'' +
                ", evAdresi='" + evAdresi + '\'' +
                ", okul='" + okul + '\'' +
                ", bolum='" + bolum + '\'' +
                ", sinif=" + sinif +
                ", ogrenciNo=" + ogrenciNo +
                '}';
    }
}
