package Hafta4.Kapsulleme;

import java.util.Scanner;

public class Ornek2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Telefon[] telefonlar = new Telefon[sc.nextInt()];


        for (int i = 0; i < telefonlar.length; i++) {
            telefonlar[i] = new Telefon();
            System.out.println("Telefonun markasını giriniz:");
            telefonlar[i].setMarka(sc.next());
            System.out.println("Telefonun modelini giriniz:");
            telefonlar[i].setModel(sc.next());
            System.out.println("Telefonun rengini giriniz:");
            telefonlar[i].setRenk(sc.next());
            System.out.println("Telefonun kamera sayısınını giriniz:");
            telefonlar[i].setKameraSayisi(sc.nextShort());
            System.out.println("Telefonun ram miktarını giriniz:");
            telefonlar[i].setRamMiktari(sc.nextShort());
            System.out.println("Telefonun hafıza miktarını giriniz:");
            telefonlar[i].setHafizaMiktari(sc.nextShort());
            System.out.println("Telefonun işlemci çekirdek sayısını giriniz:");
            telefonlar[i].setIslemciCekirdekSayisi(sc.nextShort());
            System.out.println("Nfc özelliği var mı? (true/false)");
            telefonlar[i].setNfc(sc.nextBoolean());
            System.out.println("Çift sim kart özelliği var mı? (true/false)");
            telefonlar[i].setCiftSimkart(sc.nextBoolean());
            System.out.println("----");
        }

        for (Telefon t:telefonlar) {
            System.out.println("Telefonun Markası:"+t.getMarka());
            System.out.println("Telefonun Modeli:"+t.getModel());
            System.out.println("Telefonun Rengi:"+t.getRenk());
            System.out.println("Telefonun Hafızası:"+t.getHafizaMiktari());
            System.out.println("Telefonun Kamera Sayısı:"+t.getKameraSayisi());
            System.out.println("Telefonun İşlemci Çekirdek Sayısı:"+t.getIslemciCekirdekSayisi());

            if(t.isCiftSimkart()){
                System.out.println("Telefon çift sim kartlıdır.");
            }else{
                System.out.println("Telefon çift sim kartlı değildir.");
            }

            if(t.isNfc()){
                System.out.println("Telefon nfc desteklemektedir.");
            }else{
                System.out.println("Telefon nfc desteklememektedir.");
            }
            System.out.println("-----");
        }


    }
}
