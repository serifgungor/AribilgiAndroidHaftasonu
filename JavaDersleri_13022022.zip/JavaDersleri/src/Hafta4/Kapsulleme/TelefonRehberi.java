package Hafta4.Kapsulleme;

public class TelefonRehberi {
    private String adSoyad;
    private String telefonNumarasi;
    private String email;

    public TelefonRehberi() {
    }

    public TelefonRehberi(String adSoyad, String telefonNumarasi, String email) {
        this.adSoyad = adSoyad;
        this.telefonNumarasi = telefonNumarasi;
        this.email = email;
    }

    public String getAdSoyad() {
        return adSoyad;
    }

    public void setAdSoyad(String adSoyad) {
        this.adSoyad = adSoyad;
    }

    public String getTelefonNumarasi() {
        return telefonNumarasi;
    }

    public void setTelefonNumarasi(String telefonNumarasi) {
        this.telefonNumarasi = telefonNumarasi;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
