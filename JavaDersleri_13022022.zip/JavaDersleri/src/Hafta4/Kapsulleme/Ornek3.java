package Hafta4.Kapsulleme;

import java.util.ArrayList;

public class Ornek3 {
    public static void main(String[] args) {

        ArrayList<TelefonRehberi> rehberListesi = new ArrayList<>();


            rehberListesi.add(new TelefonRehberi(
                    "Şerif Güngör",
                    "02120003355",
                    "gungoronline@gmail.com"
            ));

            ArrayList<String> iller = new ArrayList<>();
        iller.add("İstanbul");
        iller.add("Ankara");
        iller.remove("Ankara");



        for (int i = 0; i < rehberListesi.size(); i++) {
            System.out.println(rehberListesi.get(i).getAdSoyad());
            System.out.println(rehberListesi.get(i).getEmail());
            System.out.println(rehberListesi.get(i).getTelefonNumarasi());
        }

        for (TelefonRehberi r:rehberListesi) {
            System.out.println(r.getTelefonNumarasi());
            System.out.println(r.getEmail());
            System.out.println(r.getAdSoyad());
        }

        System.out.println(rehberListesi.size());





    }
}
