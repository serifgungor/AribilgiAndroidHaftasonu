package Hafta4.Kapsulleme;

public class Telefon {
    private String marka;
    private String model;
    private String renk;
    private short kameraSayisi;
    private short ramMiktari;
    private short hafizaMiktari;
    private short islemciCekirdekSayisi;
    private boolean nfc;
    private boolean ciftSimkart;

    public Telefon() {
    }

    public Telefon(String marka, String model, String renk, short kameraSayisi, short ramMiktari, short hafizaMiktari, short islemciCekirdekSayisi, boolean nfc, boolean ciftSimkart) {
        this.marka = marka;
        this.model = model;
        this.renk = renk;
        this.kameraSayisi = kameraSayisi;
        this.ramMiktari = ramMiktari;
        this.hafizaMiktari = hafizaMiktari;
        this.islemciCekirdekSayisi = islemciCekirdekSayisi;
        this.nfc = nfc;
        this.ciftSimkart = ciftSimkart;
    }

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getRenk() {
        return renk;
    }

    public void setRenk(String renk) {
        this.renk = renk;
    }

    public short getKameraSayisi() {
        return kameraSayisi;
    }

    public void setKameraSayisi(short kameraSayisi) {
        this.kameraSayisi = kameraSayisi;
    }

    public short getRamMiktari() {
        return ramMiktari;
    }

    public void setRamMiktari(short ramMiktari) {
        this.ramMiktari = ramMiktari;
    }

    public short getHafizaMiktari() {
        return hafizaMiktari;
    }

    public void setHafizaMiktari(short hafizaMiktari) {
        this.hafizaMiktari = hafizaMiktari;
    }

    public short getIslemciCekirdekSayisi() {
        return islemciCekirdekSayisi;
    }

    public void setIslemciCekirdekSayisi(short islemciCekirdekSayisi) {
        this.islemciCekirdekSayisi = islemciCekirdekSayisi;
    }

    public boolean isNfc() {
        return nfc;
    }

    public void setNfc(boolean nfc) {
        this.nfc = nfc;
    }

    public boolean isCiftSimkart() {
        return ciftSimkart;
    }

    public void setCiftSimkart(boolean ciftSimkart) {
        this.ciftSimkart = ciftSimkart;
    }
}
