package Hafta4.Kalitim;

public class Insan extends Adem {
    public void kahkahaAt(){
        System.out.println("İnsan Kahkaha Attı");
    }

    public void konus(){
        super.konus();
        System.out.println("insan konuştu");
    }

    /*
    Üst sınıftaki bir davranışın çağrılan sınıfta değiştirilmesi veya
    yeni özellikler kazandırılması için tekrar üretilmesi durumuna
    method ovverride denir.
     */
}
