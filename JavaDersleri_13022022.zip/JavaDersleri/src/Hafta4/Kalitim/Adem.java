package Hafta4.Kalitim;

public class Adem {
    public void uyu(){
        System.out.println("Adem uyudu");
    }
    public void yemekYe(){
        System.out.println("Adem yemek yedi");
    }
    public void konus(){
        System.out.println("Adem konuştu");
    }
    public void yuru(){
        System.out.println("Adem yürüdü");
    }
    public void kos(){
        System.out.println("Adem koştu");
    }
}
