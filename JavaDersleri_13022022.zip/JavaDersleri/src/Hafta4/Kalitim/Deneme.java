package Hafta4.Kalitim;

public class Deneme {
    public static void main(String[] args) {
        Insan insan = new Insan();
        insan.kahkahaAt();
        insan.konus();

        System.out.println("---");

        Adem adem = new Adem();
        adem.konus();


    }
}
