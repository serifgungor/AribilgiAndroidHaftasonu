package com.serifgungor.volleypost.Activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.serifgungor.volleypost.Model.Kullanici;
import com.serifgungor.volleypost.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class GirisKayitActivity extends AppCompatActivity {

    Button btnGiris,btnKayit;
    EditText etUsername,etPassword;
    StringRequest request;
    RequestQueue queue;
    boolean loginResponse;
    int registerResponse; //1 kayıt ok, 2 db error, 3 zaten kayıtlı
    Kullanici kullanici;


    public void girisIslemi(String username,String password){

        request = new StringRequest(
                Request.Method.POST,
                "http://192.168.18.93/androidws/login.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("giris",response);

                        //{"message":"logintrue","id":"1","username":"serif","created_at":"2022-05-21 09:51:26"}

                        try {
                            JSONObject obj = new JSONObject(response);
                            String message = (String) obj.get("message");

                            if("loginfalse".equals(message)){
                                loginResponse = false;
                            }else if("logintrue".equals(message)){
                                kullanici = new Kullanici();
                                kullanici.setId(obj.getInt("id"));
                                kullanici.setUsername(obj.getString("username"));
                                kullanici.setCreated_at(obj.getString("created_at"));;

                                loginResponse = true;
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //{"message":"loginfalse"}
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            //web sayfasına veri göndermek için getParams metodu kullanılır.
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> map = new HashMap<>();
                map.put("username",username);
                map.put("pass",password);
                return map;
            }
        };

        queue.add(request);
    }

    public void kayitIslemi(String username,String password){
        request = new StringRequest(
                Request.Method.POST,
                "http://192.168.18.93/androidws/register.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        //kayıt başarılı yada başarısız yazısını göreceğimiz alan

                        //{"message":"registertrue","id":"3","username":"hamza1","created_at":"2022-05-21 10:39:31"}
                        //{"message":"registerfailed"}
                        //{"message":"register_already_exists_user"}

                        try {
                            JSONObject obj = new JSONObject(response);
                            String message = (String) obj.getString("message");

                            if("registertrue".equals(message)){
                                kullanici = new Kullanici();
                                kullanici.setId(obj.getInt("id"));
                                kullanici.setUsername(obj.getString("username"));
                                kullanici.setCreated_at(obj.getString("created_at"));;
                                registerResponse = 1;
                            }else if("registerfailed".equals(message)){
                                registerResponse = 2;
                            }else if("register_already_exists_user".equals(message)){
                                registerResponse = 3;
                            }else if("notnullarea".equals(message)){
                                registerResponse = 4;
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> map = new HashMap<>();
                map.put("username",username);
                map.put("pass",password);
                return map;
            }
        };
        queue.add(request);

    }



    public void init(){
        queue = new Volley().newRequestQueue(getApplicationContext());
        btnGiris = findViewById(R.id.btnGiris);
        btnKayit = findViewById(R.id.btnKayit);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        btnGiris.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                girisIslemi(etUsername.getText().toString(),etPassword.getText().toString());
                if(loginResponse){

                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    intent.putExtra("kullanici",kullanici);
                    startActivity(intent);

                    //Toast.makeText(getApplicationContext(), "Giriş başarılı", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Kullanıcı adı yada şifre hatalı", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnKayit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kayitIslemi(etUsername.getText().toString(),etPassword.getText().toString());
                if(registerResponse==1){
                    Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                    intent.putExtra("kullanici",kullanici);
                    startActivity(intent);
                    //Toast.makeText(getApplicationContext(), "Kayıt işlemi başarılı", Toast.LENGTH_SHORT).show();
                }else if(registerResponse==2){
                    Toast.makeText(getApplicationContext(), "Sistemde sorun oluştu, tekrar deneyin !", Toast.LENGTH_SHORT).show();
                }else if(registerResponse==3){
                    Toast.makeText(getApplicationContext(), "Kullanıcı zaten kayıtlı !", Toast.LENGTH_SHORT).show();
                }else if(registerResponse==4){
                    Toast.makeText(getApplicationContext(), "Kullanıcı adı yada şifre boş geçilemez", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giris_kayit);
        init();
    }
}