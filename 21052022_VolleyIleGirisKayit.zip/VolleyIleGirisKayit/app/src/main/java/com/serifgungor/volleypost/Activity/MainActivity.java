package com.serifgungor.volleypost.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.serifgungor.volleypost.Adapter.AdapterHaber;
import com.serifgungor.volleypost.Model.Haber;
import com.serifgungor.volleypost.Model.Kullanici;
import com.serifgungor.volleypost.R;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    StringRequest req;
    RequestQueue queue;
    ArrayList<Haber> haberler;
    AdapterHaber adapterHaber;
    ListView listViewHaberler;
    Kullanici kullanici;

    public void WebServistenHaberleriGetir() {
        queue = new Volley().newRequestQueue(getApplicationContext());
        Type listType = new TypeToken<ArrayList<Haber>>(){}.getType();
        haberler = new ArrayList<>();

        req = new StringRequest(
                Request.Method.POST,
                "http://192.168.18.93/androidws/index.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Log.d("çıktı",response);
                        haberler = new Gson().fromJson(response,listType);
                        //Haber haber = gson.fromJson(response,Haber.class);
                        /*
                        for (Haber haber:haberler) {
                            //haberler.add(haber);
                            //Log.d("haber",haber.baslik);
                        }
                        */
                        adapterHaber = new AdapterHaber(getApplicationContext(),haberler);
                        listViewHaberler.setAdapter(adapterHaber);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        queue.add(req);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.id_add){
            Intent intent = new Intent(getApplicationContext(),HaberEkleActivity.class);
            intent.putExtra("kullanici",kullanici);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listViewHaberler = findViewById(R.id.listViewHaberler);

        kullanici = (Kullanici) getIntent().getSerializableExtra("kullanici");

        WebServistenHaberleriGetir();
    }
}