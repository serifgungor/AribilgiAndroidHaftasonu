package com.serifgungor.volleypost.Model;

import java.io.Serializable;

public class Haber implements Serializable {
    public String id;
    public String kullanici_id;
    public String baslik;
    public String haber;
    public String tarih;
}
