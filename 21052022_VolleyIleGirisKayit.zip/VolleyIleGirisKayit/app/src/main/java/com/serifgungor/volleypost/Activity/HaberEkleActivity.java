package com.serifgungor.volleypost.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.serifgungor.volleypost.Model.Kullanici;
import com.serifgungor.volleypost.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class HaberEkleActivity extends AppCompatActivity {

    Kullanici kullanici;
    EditText etHaberBaslik,etHaberIcerik;
    Button btnHaberEkle;
    StringRequest request;
    RequestQueue queue;

    public void init(){
        queue = Volley.newRequestQueue(getApplicationContext());
        etHaberBaslik = findViewById(R.id.etHaberBaslik);
        etHaberIcerik = findViewById(R.id.etHaberDetay);
        btnHaberEkle = findViewById(R.id.btnHaberEkle);
        btnHaberEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                request = new StringRequest(
                        Request.Method.POST,
                        "http://192.168.18.93/androidws/haberekle.php",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                try {
                                    JSONObject obj = new JSONObject(response);
                                    String message = obj.getString("message");
                                    if("habereklendi".equals(message)){
                                        Toast.makeText(getApplicationContext(), "Haber eklendi", Toast.LENGTH_SHORT).show();
                                        etHaberBaslik.setText("");
                                        etHaberIcerik.setText("");
                                    }else if("habereklenemedi".equals(message)){
                                        Toast.makeText(getApplicationContext(), "Haber eklenemedi", Toast.LENGTH_SHORT).show();
                                    }else if("notnullarea".equals(message)){
                                        Toast.makeText(getApplicationContext(), "Boş alan bırakılamaz", Toast.LENGTH_SHORT).show();
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                            }
                        }
                ){
                    @Nullable
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String,String> hm = new HashMap<>();
                        hm.put("kullanici_id",""+kullanici.getId());
                        hm.put("haber_adi",etHaberBaslik.getText().toString());
                        hm.put("haber_icerigi",etHaberIcerik.getText().toString());
                        return hm;
                    }
                };

                queue.add(request);

            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_haber_ekle);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.setTitle("Haber ekle");
        init();
        kullanici = (Kullanici) getIntent().getSerializableExtra("kullanici");
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}