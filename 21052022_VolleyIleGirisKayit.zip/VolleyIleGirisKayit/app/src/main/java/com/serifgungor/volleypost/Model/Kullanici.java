package com.serifgungor.volleypost.Model;

import java.io.Serializable;

public class Kullanici implements Serializable {
    private int id;
    private String username;
    private String created_at;

    public Kullanici() {
    }

    public Kullanici(int id, String username, String created_at) {
        this.id = id;
        this.username = username;
        this.created_at = created_at;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }
}
