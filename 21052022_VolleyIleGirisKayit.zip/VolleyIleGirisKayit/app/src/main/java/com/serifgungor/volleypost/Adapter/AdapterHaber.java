package com.serifgungor.volleypost.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.serifgungor.volleypost.Model.Haber;
import com.serifgungor.volleypost.R;

import java.util.ArrayList;

public class AdapterHaber extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Haber> haberler;

    public AdapterHaber() {
    }

    public AdapterHaber(Context context, ArrayList<Haber> haberler) {
        this.context = context;
        this.haberler = haberler;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return haberler.size();
    }

    @Override
    public Haber getItem(int position) {
        return haberler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       View v = layoutInflater.inflate(R.layout.haber_row,null);
       TextView tvBaslik = v.findViewById(R.id.tvHaberBaslik);
       tvBaslik.setText(haberler.get(position).baslik);
       return v;
    }
}
