package com.serifgungor.imageviewkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView ivResim;
    Button btnDegistir;

    int[] resimler = new int[4];
    int sayac = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resimler[0] = R.drawable.kedi;
        resimler[1] = R.drawable.kopek;
        resimler[2] = R.drawable.kurt;
        resimler[3] = R.drawable.kuzu;

        ivResim = findViewById(R.id.ivResim);
        btnDegistir = findViewById(R.id.btnDegistir);
        ivResim.setImageResource(resimler[0]);

        btnDegistir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sayac==resimler.length-1){
                    sayac = 0;
                }else{
                    sayac++;
                }
                ivResim.setImageResource(resimler[sayac]);
            }
        });
    }
}