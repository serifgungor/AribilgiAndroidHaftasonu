package com.serifgungor.butonatiklama;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void butonaTikla(View view) {
        switch (view.getId()){
            case R.id.button7:
                Toast.makeText(getApplicationContext(), "1. butona tıklandı", Toast.LENGTH_LONG).show();
                break;
            case R.id.button8:
                Toast.makeText(getApplicationContext(), "2. butona tıklandı", Toast.LENGTH_LONG).show();
                break;
            case R.id.button9:
                Toast.makeText(getApplicationContext(), "3. butona tıklandı", Toast.LENGTH_LONG).show();
                break;
            case R.id.button10:
                Toast.makeText(getApplicationContext(), "4. butona tıklandı", Toast.LENGTH_LONG).show();
                break;
            case R.id.button11:
                Toast.makeText(getApplicationContext(), "5. butona tıklandı", Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}