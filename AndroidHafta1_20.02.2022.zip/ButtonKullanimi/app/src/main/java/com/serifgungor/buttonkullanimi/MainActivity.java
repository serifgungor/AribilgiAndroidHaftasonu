package com.serifgungor.buttonkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn1,btn2;
    TextView tvSayi;
    int sayi = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Referans adresi tanımlama
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        tvSayi = findViewById(R.id.tvSayi);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sayi = sayi + 1;
                tvSayi.setText(""+sayi);
            }
        });

        btn2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Log.d("baslik","butona uzun tıklandı");
                return false;
            }
        });






    }
}