package com.serifgungor.edittextkullanimi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText etSayi1,etSayi2;
    Button btnHesapla;
    TextView tvSonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvSonuc = findViewById(R.id.tvSonuc);
        btnHesapla = findViewById(R.id.btnHesapla);
        etSayi1 = findViewById(R.id.etSayi1);
        etSayi2 = findViewById(R.id.etSayi2);

        btnHesapla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                double toplamaSonucu = 0;
                double cikarmaSonucu = 0;
                double carpmaSonucu = 0;
                double bolmeSonucu = 0;

                double et1 = Double.parseDouble(etSayi1.getText().toString());
                double et2 = Double.parseDouble(etSayi2.getText().toString());

                toplamaSonucu = et1+et2;
                cikarmaSonucu = et1-et2;
                carpmaSonucu = et1*et2;
                bolmeSonucu = et1/et2;

                tvSonuc.setText("Toplama sonucu: "+toplamaSonucu+"\n"
                +"Çıkarma sonucu: "+cikarmaSonucu+"\n"
                +"Bölme sonucu: "+bolmeSonucu+"\n"
                +"Çarpma sonucu: "+carpmaSonucu+"\n");


            }
        });
    }
}