package com.serifgungor.volleypost;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    StringRequest req;
    RequestQueue queue;
    ArrayList<Haber> haberler;

    public void WebServistenHaberleriGetir() {
        queue = new Volley().newRequestQueue(getApplicationContext());
        Type listType = new TypeToken<ArrayList<Haber>>(){}.getType();
        haberler = new ArrayList<>();

        req = new StringRequest(
                Request.Method.POST,
                "http://localhost/androidws/index.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("çıktı",response);
                        haberler = new Gson().fromJson(response,listType);
                        //Haber haber = gson.fromJson(response,Haber.class);
                        for (Haber haber:haberler) {
                            Log.d("haber",haber.baslik);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        queue.add(req);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebServistenHaberleriGetir();
    }
}