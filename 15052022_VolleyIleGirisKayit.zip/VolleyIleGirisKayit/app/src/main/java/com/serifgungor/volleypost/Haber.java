package com.serifgungor.volleypost;

public class Haber {
    public String id;
    public String baslik;
    public String haber;
    public String tarih;
}
