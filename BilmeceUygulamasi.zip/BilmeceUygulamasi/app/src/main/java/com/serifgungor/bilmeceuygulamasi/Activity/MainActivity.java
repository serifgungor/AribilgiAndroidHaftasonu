package com.serifgungor.bilmeceuygulamasi.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.nex3z.flowlayout.FlowLayout;
import com.serifgungor.bilmeceuygulamasi.Model.Country;
import com.serifgungor.bilmeceuygulamasi.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tvScore,tvMoney;
    ImageView ivFlag;
    Button btnSolve,btnHelp,btnHint;
    FlowLayout flowLayout,flowLayoutAnswer;
    ArrayList<Country> countries = new ArrayList<>();
    ArrayList<Character> characters = new ArrayList<>();
    ArrayList<Character> answerCharacters = new ArrayList<>();

    public void fillCountries(){
        countries.add(new Country("https://raw.githubusercontent.com/serifgungor/AribilgiAndroidHaftasonu/main/tr.jpg","TÜRKİYE"));
        countries.add(new Country("https://raw.githubusercontent.com/serifgungor/AribilgiAndroidHaftasonu/main/gr.jpg","YUNANİSTAN"));
        countries.add(new Country("https://raw.githubusercontent.com/serifgungor/AribilgiAndroidHaftasonu/main/ir.jpg","İRAN"));
        countries.add(new Country("https://raw.githubusercontent.com/serifgungor/AribilgiAndroidHaftasonu/main/eg.jpg","MISIR"));
        countries.add(new Country("https://raw.githubusercontent.com/serifgungor/AribilgiAndroidHaftasonu/main/sr.jpg","SURİYE"));
    }

    public void showCountry(int index){
        Country c = countries.get(index);
        for (int i = 0; i < c.getCountryName().length(); i++) {
            characters.add(new Character(c.getCountryName().charAt(i)));
            TextView tv = new TextView(getApplicationContext());
            tv.setText("");//c.getCountryName().charAt(i)
            tv.setTextSize(20f);
            tv.setId(10+(i));
            tv.setOnClickListener(this);
            tv.setGravity(Gravity.CENTER);
            tv.setTextColor(Color.parseColor("#2f76cb"));
            tv.setBackgroundResource(R.drawable.buttonstyle);
            flowLayout.addView(tv);
        }
        Glide.with(getApplicationContext()).load(c.getFlag()).into(ivFlag);
    }

    public void showAnswerCharacters(){
        answerCharacters.addAll(characters);
        int difference = (18)-characters.size();
        Random rnd = new Random();
        String rndChars = "QWERTYUIOPĞÜASDFGHJKLŞİZXCVBNMÖÇ";
        for (int i = 0; i < difference; i++) {
            answerCharacters.add(new Character(rndChars.charAt(rnd.nextInt(rndChars.length()))));
        }
        Collections.shuffle(answerCharacters);
        // Add all views to layout
        for (int i = 0; i < answerCharacters.size(); i++) {
            TextView tv = new TextView(getApplicationContext());
            tv.setText(""+answerCharacters.get(i));
            tv.setTextSize(20f);
            tv.setGravity(Gravity.CENTER);
            tv.setTextColor(Color.parseColor("#2f76cb"));
            tv.setBackgroundResource(R.drawable.buttonstyle);
            flowLayoutAnswer.addView(tv);
        }
    }

    public void init(){
        tvScore = findViewById(R.id.tvScore);
        tvMoney = findViewById(R.id.tvMoney);
        ivFlag = findViewById(R.id.ivFlag);
        btnSolve = findViewById(R.id.btnSolve);
        btnHelp = findViewById(R.id.btnHelp);
        btnHint = findViewById(R.id.btnHint);
        flowLayout = findViewById(R.id.flowLayout);
        flowLayoutAnswer = findViewById(R.id.flowLayoutAnswer);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.getSupportActionBar().hide();
        //this.setTitle("Başlık");
        init();
        fillCountries();
        showCountry(0);
        showAnswerCharacters();

    }

    @Override
    public void onClick(View view) {

    }
}