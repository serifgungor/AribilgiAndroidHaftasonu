package com.sos_oyunu.android.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sos_oyunu.android.Adapter.OdaAdapter;
import com.sos_oyunu.android.Model.Oda;
import com.sos_oyunu.android.R;

import java.util.ArrayList;
import java.util.HashMap;

public class OdalarActivity extends AppCompatActivity {
    DatabaseReference myRef;
    Button btnOdaOlustur;
    Long son_oda_id = 0l;
    ArrayList<Oda> odalar = new ArrayList<>();
    OdaAdapter odaAdapter;
    ListView listViewOdalar;

    public void yeniOdaOlustur(String birinciOyuncuAdi){
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot sn : snapshot.getChildren()) {
                    if("son_oda_id".equals(sn.getKey())){
                        son_oda_id = (Long) sn.getValue();
                        Log.d("firebase","Son oda id'si: "+son_oda_id);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        Long olusacakOdaId = son_oda_id+1;
        myRef = FirebaseDatabase.getInstance().getReference().child("odalar");
        myRef.child("son_oda_id").setValue(olusacakOdaId);

        myRef = FirebaseDatabase.getInstance().getReference().child("odalar/"+olusacakOdaId);
        myRef.child("islem_kisi").setValue("1");
        myRef.child("odaId").setValue(""+olusacakOdaId);
        myRef.child("aksiyon").setValue(" ");
        for (int i = 1; i <=9 ; i++) {
            myRef.child("aksiyon/kutu"+i).setValue(" ");
        }
        myRef.child("oyuncu1").setValue(birinciOyuncuAdi);
        myRef.child("oyuncu2").setValue("null");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_odalar);
        this.getSupportActionBar().hide();
        myRef = FirebaseDatabase.getInstance().getReference().child("odalar");

        listViewOdalar = findViewById(R.id.lvOdaKisiler);

        //myRef.child("son_oda_id").setValue("0");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                odalar.clear();
                for (DataSnapshot sn : snapshot.getChildren()) {
                    if (!"son_oda_id".equals(sn.getKey())) {
                        try{
                            HashMap<String,String> hm = new HashMap<>();
                            hm = (HashMap<String, String>) sn.getValue();
                            //Log.d("keyvalue", hm.toString());
                            Oda oda = new Oda();
                            oda.odaId = Integer.parseInt(hm.get("odaId"));
                            oda.aksiyon = null;
                            oda.islem_kisi = Integer.parseInt(hm.get("islem_kisi"));
                            oda.oyuncu1 = hm.get("oyuncu1");
                            oda.oyuncu2 = hm.get("oyuncu2");

                            odalar.add(oda);
                        }catch (Exception e){

                        }

                    }
                }

                odaAdapter = new OdaAdapter(odalar,getApplicationContext());
                listViewOdalar.setAdapter(odaAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        btnOdaOlustur = findViewById(R.id.btnOdaOlustur);
        btnOdaOlustur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final EditText et = new EditText(getApplicationContext());
                AlertDialog.Builder adb = new AlertDialog.Builder(OdalarActivity.this);
                adb.setTitle("Adınızı giriniz");
                adb.setView(et);
                adb.setPositiveButton("Oluştur", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String yazi = et.getText().toString();
                        yeniOdaOlustur(yazi);
                    }
                });
                adb.setNegativeButton("İptal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                adb.create();
                adb.show();





                /*
                myRef = FirebaseDatabase.getInstance().getReference().child("odalar/"+olusacakOdaId);
                ArrayList<String> aksiyonlar = new ArrayList<>();
                for (int i = 1; i <=9 ; i++) {
                    aksiyonlar.add(" ");
                }
                myRef.push().setValue(new Oda(1,1,aksiyonlar,"oyuncu1","oyuncu2"));
                */
            }
        });

        listViewOdalar.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),OyunActivity.class);
                intent.putExtra("oda",odalar.get(i));
                startActivity(intent);
            }
        });
    }
}