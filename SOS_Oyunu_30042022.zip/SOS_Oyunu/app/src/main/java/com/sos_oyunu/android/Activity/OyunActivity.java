package com.sos_oyunu.android.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.nex3z.flowlayout.FlowLayout;
import com.sos_oyunu.android.Model.Oda;
import com.sos_oyunu.android.R;

public class OyunActivity extends AppCompatActivity implements View.OnClickListener {

    FlowLayout flowLayout;
    Oda oda;
    DatabaseReference myRef;

    public void bosKutulariUret(){
        for (int i = 1; i <=9 ; i++) {
            final ImageView iv = new ImageView(getApplicationContext());
            iv.setImageResource(R.drawable.bos);
            iv.setOnClickListener(this::onClick);
            iv.setTag("bos,kutu"+i);
            flowLayout.addView(iv);
        }
    }

    public void init(){
        oda = (Oda)getIntent().getSerializableExtra("oda");
        flowLayout = findViewById(R.id.flowLayout);
        flowLayout.setMaxRows(3);
        myRef = FirebaseDatabase.getInstance().getReference().child("odalar/"+oda.odaId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oyun);
        init();
        bosKutulariUret();

    }

    @Override
    public void onClick(View view) {
        ImageView iv = (ImageView)view;
        if(iv.getTag().toString().startsWith("bos")){
            Toast.makeText(getApplicationContext(), "tıklandı", Toast.LENGTH_SHORT).show();
            iv.setImageResource(R.drawable.s);
            String[] splitted = iv.getTag().toString().split(",");
            myRef.child("aksiyon").child(splitted[1]).setValue("S");
        }
    }
}