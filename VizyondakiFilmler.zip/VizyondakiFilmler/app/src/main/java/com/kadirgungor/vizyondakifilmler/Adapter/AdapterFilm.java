package com.kadirgungor.vizyondakifilmler.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.kadirgungor.vizyondakifilmler.Model.Film;
import com.kadirgungor.vizyondakifilmler.R;

import java.util.ArrayList;

public class AdapterFilm extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Film> filmler;

    public AdapterFilm() {}

    public AdapterFilm(Context context,ArrayList<Film> filmler){
        this.context = context;
        this.filmler = filmler;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return filmler.size();
    }

    @Override
    public Film getItem(int i) {
        return filmler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = layoutInflater.inflate(R.layout.film_row,null);
        ImageView ivKapakGorseli = v.findViewById(R.id.ivKapakGorseli);
        Glide.with(v.getContext()).load(filmler.get(i).getGorsel()).into(ivKapakGorseli);

        TextView tvFilmAdi = v.findViewById(R.id.tvFilmAdi);
        TextView tvTur = v.findViewById(R.id.tvFilmTur);
        TextView tvYil = v.findViewById(R.id.tvFilmCikisYili);
        TextView tvSure = v.findViewById(R.id.tvFilmSure);
        tvFilmAdi.setText(filmler.get(i).getFilmAdi());
        tvYil.setText(""+filmler.get(i).getVizyonaCikisYili());
        tvSure.setText(""+filmler.get(i).getSure());
        tvTur.setText(filmler.get(i).getTurler()[0]);
        


        return v;
    }
}
