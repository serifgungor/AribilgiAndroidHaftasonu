package com.kadirgungor.vizyondakifilmler.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.kadirgungor.vizyondakifilmler.Adapter.AdapterFilm;
import com.kadirgungor.vizyondakifilmler.Model.Film;
import com.kadirgungor.vizyondakifilmler.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listViewFilmler;
    AdapterFilm adapterFilm;
    ArrayList<Film> filmler = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //ListView'ı tanımla
        listViewFilmler = findViewById(R.id.listViewFilmler);
        //Arrayliste veri ekle
        //String filmAdi, String gorsel, String ozetYazisi, String[] turler, int vizyonaCikisYili, int sure
        filmler.add(new Film("The Batman","https://media.cinemaximum.com.tr/255//Files/POSTER/TR_TURKEY_TheBatman_VERT_MONTAGE_Afis_y.jpg","",new String[]{"Aksiyon"},2022,175));
        filmler.add(new Film("Bergen","https://media.cinemaximum.com.tr/255//Files/POSTER/brgn.jpg","",new String[]{"Biyografi"},2022,145));
        filmler.add(new Film("Kayıp Şehir","https://media.cinemaximum.com.tr/255//Files/POSTER/THELOSTC_TY.jpg","",new String[]{"Aksiyon"},2022,112));
        filmler.add(new Film("Ambulans","https://media.cinemaximum.com.tr/255//files/movie_posters/HO00005037_637816629447758441_ambulans.png","",new String[]{"Aksiyon"},2022,136));
        //adapter'ı tanımla
        adapterFilm = new AdapterFilm(getApplicationContext(),filmler);
        //adapter'dan gelen dataları listview'a gönderdik.
        listViewFilmler.setAdapter(adapterFilm);

    }
}