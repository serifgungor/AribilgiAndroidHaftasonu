package com.kadirgungor.vizyondakifilmler.Model;

import java.io.Serializable;

public class Film implements Serializable {
    private String filmAdi;
    private String gorsel;
    private String ozetYazisi;
    private String[] turler;
    private int vizyonaCikisYili;
    private int sure;

    public Film() { }

    public Film(String filmAdi, String gorsel, String ozetYazisi, String[] turler, int vizyonaCikisYili, int sure) {
        this.filmAdi = filmAdi;
        this.gorsel = gorsel;
        this.ozetYazisi = ozetYazisi;
        this.turler = turler;
        this.vizyonaCikisYili = vizyonaCikisYili;
        this.sure = sure;
    }

    public String getFilmAdi() {
        return filmAdi;
    }

    public void setFilmAdi(String filmAdi) {
        this.filmAdi = filmAdi;
    }

    public String getGorsel() {
        return gorsel;
    }

    public void setGorsel(String gorsel) {
        this.gorsel = gorsel;
    }

    public String getOzetYazisi() {
        return ozetYazisi;
    }

    public void setOzetYazisi(String ozetYazisi) {
        this.ozetYazisi = ozetYazisi;
    }

    public String[] getTurler() {
        return turler;
    }

    public void setTurler(String[] turler) {
        this.turler = turler;
    }

    public int getVizyonaCikisYili() {
        return vizyonaCikisYili;
    }

    public void setVizyonaCikisYili(int vizyonaCikisYili) {
        this.vizyonaCikisYili = vizyonaCikisYili;
    }

    public int getSure() {
        return sure;
    }

    public void setSure(int sure) {
        this.sure = sure;
    }
}
