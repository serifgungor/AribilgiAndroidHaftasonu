package com.example.yemekapponline.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.yemekapponline.Model.Tarif;
import com.example.yemekapponline.R;

import java.util.ArrayList;

public class CategoryRecipe extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Tarif> tarifler;

    public CategoryRecipe() {
    }

    public CategoryRecipe(Context context, ArrayList<Tarif> tarifler) {
        this.context = context;
        this.tarifler = tarifler;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return tarifler.size();
    }

    @Override
    public Tarif getItem(int position) {
        return tarifler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.category_recipe,null);

        TextView tvTarifAdi = v.findViewById(R.id.tvTarifAdi);
        TextView tvPisirmeSuresi = v.findViewById(R.id.tvPisirmeSuresi);
        TextView tvKisiSayisi = v.findViewById(R.id.tvKisiSayisi);
        ImageView ivRecipeImg = v.findViewById(R.id.ivRecipeImg);

        Glide.with(context).load(tarifler.get(position).resim).into(ivRecipeImg);
        tvTarifAdi.setText(tarifler.get(position).baslik);
        tvPisirmeSuresi.setText(tarifler.get(position).pisirme_suresi);
        tvKisiSayisi.setText(tarifler.get(position).kisi_sayisi);

        return v;
    }
}
