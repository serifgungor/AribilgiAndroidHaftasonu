package com.example.yemekapponline.Model;

import java.io.Serializable;

public class Kategori implements Serializable {
    public String baslik;
    public String gorsel;
}
