package com.example.yemekapponline.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.yemekapponline.Adapter.CategoryRecipe;
import com.example.yemekapponline.Model.Kategori;
import com.example.yemekapponline.Model.Tarif;
import com.example.yemekapponline.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class RecipeActivity extends AppCompatActivity {

    Kategori kategori;
    ArrayList<Tarif> tarifler;
    DatabaseReference dbRef;
    ListView listViewTarifler;
    CategoryRecipe adapter;

    public void tarifleriGetir(){
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                tarifler.clear();
                for(DataSnapshot sn:snapshot.getChildren()){

                    Tarif tarif = sn.getValue(Tarif.class);
                    if(kategori.baslik.equals(tarif.kategoriBaslik)){
                        tarifler.add(tarif);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    public void init(){
        tarifler = new ArrayList<>();
        kategori = (Kategori) getIntent().getSerializableExtra("kategori");
        this.setTitle(kategori.baslik);
        listViewTarifler = findViewById(R.id.listViewTarifler);

        dbRef = FirebaseDatabase.getInstance().getReference("tarifler");
        tarifleriGetir();
        adapter = new CategoryRecipe(getApplicationContext(),tarifler);
        listViewTarifler.setAdapter(adapter);
        listViewTarifler.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),RecipeDetailActivity.class);
                intent.putExtra("tarif",tarifler.get(position));
                startActivity(intent);
            }
        });



    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);
        init();
    }
}