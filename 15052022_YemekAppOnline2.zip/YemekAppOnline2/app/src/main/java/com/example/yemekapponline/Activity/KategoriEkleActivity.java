package com.example.yemekapponline.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.yemekapponline.Model.Kategori;
import com.example.yemekapponline.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class KategoriEkleActivity extends AppCompatActivity {

    EditText etBaslik,etResim;
    Button btnOlustur;
    DatabaseReference dbRef;
    
    public void init(){
        dbRef = FirebaseDatabase.getInstance().getReference("kategoriler");

        etBaslik = findViewById(R.id.etBaslik);
        etResim = findViewById(R.id.etResim);
        btnOlustur = findViewById(R.id.btnKategoriyiOlustur);
        btnOlustur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Kategori k = new Kategori();
                k.baslik = etBaslik.getText().toString();
                k.gorsel = etResim.getText().toString();
                dbRef.push().setValue(k);
                finish();
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kategori_ekle);
        init();
    }
}