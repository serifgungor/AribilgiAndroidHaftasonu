package com.example.yemekapponline.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.yemekapponline.Model.Tarif;
import com.example.yemekapponline.R;

public class RecipeDetailActivity extends AppCompatActivity {
    Tarif tarif;

    ImageView ivRdImage;
    TextView tvRdBaslik,tvRdKisiSayisi,tvRdPisirmeSuresi,tvRdHazirlanmaSuresi,tvRdPaylasanKisi,tvRdHazirlanisi;
    LinearLayout linearLayoutMalzemeler,linearLayoutAlerjenler;

    public void init(){
        tarif = (Tarif)getIntent().getSerializableExtra("tarif");
        this.setTitle(tarif.baslik);

        ivRdImage = findViewById(R.id.ivRdImage);
        tvRdBaslik = findViewById(R.id.tvRdBaslik);
        tvRdKisiSayisi = findViewById(R.id.tvRdKisiSayisi);
        tvRdPisirmeSuresi = findViewById(R.id.tvRdPisirmeSuresi);
        tvRdHazirlanmaSuresi = findViewById(R.id.tvRdHazirlanmaSuresi);
        tvRdPaylasanKisi = findViewById(R.id.tvRdPaylasanKisi);
        tvRdHazirlanisi = findViewById(R.id.tvRdHazirlanisi);
        linearLayoutMalzemeler = findViewById(R.id.linearLayoutMalzemeler);
        linearLayoutAlerjenler = findViewById(R.id.linearLayoutAlerjenler);

        Glide.with(getApplicationContext()).load(tarif.resim).into(ivRdImage);
        tvRdBaslik.setText(tarif.baslik);
        tvRdPisirmeSuresi.setText(tarif.pisirme_suresi);
        tvRdKisiSayisi.setText(tarif.kisi_sayisi);
        tvRdHazirlanisi.setText(tarif.yapilisi);
        tvRdHazirlanmaSuresi.setText(tarif.hazirlanma_suresi);
        tvRdPaylasanKisi.setText(tarif.username);

        String[] malzemeler = tarif.malzemeleri.split(",");
        for (String malzeme:malzemeler) {
            CheckBox cb = new CheckBox(getApplicationContext());
            cb.setText(malzeme);
            linearLayoutMalzemeler.addView(cb);
        }

        String[] alerjenler = tarif.alerjenler.split(",");
        for (String alerjen:alerjenler) {
            CheckBox cb = new CheckBox(getApplicationContext());
            cb.setText(alerjen);
            linearLayoutAlerjenler.addView(cb);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail);
        init();
    }
}