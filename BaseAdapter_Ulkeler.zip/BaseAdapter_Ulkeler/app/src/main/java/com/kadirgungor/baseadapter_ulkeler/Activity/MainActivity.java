package com.kadirgungor.baseadapter_ulkeler.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.kadirgungor.baseadapter_ulkeler.Adapter.AdapterUlke;
import com.kadirgungor.baseadapter_ulkeler.Model.Ulke;
import com.kadirgungor.baseadapter_ulkeler.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listviewUlkeler;
    AdapterUlke adapterUlke;

    public void init(){
        listviewUlkeler = findViewById(R.id.listviewUlkeler);
    }

    public ArrayList<Ulke> getUlkeler(){
        ArrayList<Ulke> ulkeler = new ArrayList<>();
        ulkeler.add(new Ulke("TÜRKİYE","ANKARA"));
        ulkeler.add(new Ulke("AZERBAYCAN","BAKÜ"));
        return ulkeler;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        adapterUlke = new AdapterUlke(getApplicationContext(),getUlkeler());
        listviewUlkeler.setAdapter(adapterUlke);

    }
}