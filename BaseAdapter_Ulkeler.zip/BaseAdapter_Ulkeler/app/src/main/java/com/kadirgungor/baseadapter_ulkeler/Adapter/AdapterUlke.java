package com.kadirgungor.baseadapter_ulkeler.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.kadirgungor.baseadapter_ulkeler.Model.Ulke;
import com.kadirgungor.baseadapter_ulkeler.R;

import java.util.ArrayList;

public class AdapterUlke extends BaseAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private ArrayList<Ulke> ulkeler;

    public AdapterUlke(){}
    public AdapterUlke(Context context,ArrayList<Ulke> ulkeler){
        this.context = context;
        this.ulkeler = ulkeler;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        return ulkeler.size();
    }

    @Override
    public Ulke getItem(int i) {
        return ulkeler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
       View v = layoutInflater.inflate(R.layout.ulke_row,null);
        TextView tvUlkeAdi = v.findViewById(R.id.tvUlkeAdi);
        TextView tvUlkeBaskent = v.findViewById(R.id.tvUlkeBaskent);
        tvUlkeAdi.setText(ulkeler.get(i).getUlkeAdi());
        tvUlkeBaskent.setText(ulkeler.get(i).getUlkeBaskent());
       return v;
    }
}
