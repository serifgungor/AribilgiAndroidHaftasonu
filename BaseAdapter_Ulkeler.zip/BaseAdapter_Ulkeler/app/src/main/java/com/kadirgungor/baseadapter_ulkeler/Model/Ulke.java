package com.kadirgungor.baseadapter_ulkeler.Model;

public class Ulke {
    private String ulkeAdi;
    private String ulkeBaskent;

    public Ulke(String ulkeAdi, String ulkeBaskent) {
        this.ulkeAdi = ulkeAdi;
        this.ulkeBaskent = ulkeBaskent;
    }

    public Ulke() {
    }

    public String getUlkeAdi() {
        return ulkeAdi;
    }

    public void setUlkeAdi(String ulkeAdi) {
        this.ulkeAdi = ulkeAdi;
    }

    public String getUlkeBaskent() {
        return ulkeBaskent;
    }

    public void setUlkeBaskent(String ulkeBaskent) {
        this.ulkeBaskent = ulkeBaskent;
    }
}
